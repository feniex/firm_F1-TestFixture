/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "SirenState.h"
#include "Tones.h"
#include "DACaudio.h"

/**********DEFINED CONSTANTS**********/
enum ChannelIndex
{
	CHANNEL_1 = 0,
	CHANNEL_2 = 1,
	CHANNEL_3 = 2,
	CHANNEL_4 = 3,
	CHANNEL_5 = 4,
	CHANNEL_6 = 5,
	NO_CHANNEL = 0xFF
};

enum BitMask
{
	BIT0 = 0x01,
	BIT1 = 0x02,
	BIT2 = 0x04,
	BIT3 = 0x08,
	BIT4 = 0x10,
	BIT5 = 0x20,
	BIT6 = 0x40,
	BIT7 = 0x80
};

static const uint8 DEFAULT_CONFIGURATION_LIST[SPEAKER_COUNT * CHANNEL_COUNT_PER_SPEAKER] = 
    {ECTOSIREN, WAIL, SLOW_YELP, PHASER, HORN, HORN_PHASER,
    COPS_SONG, WAIL, SLOW_YELP, PHASER, HORN, HORN_PHASER};

static const uint16 EEPROM_KEY_INDEX = 0xFF;
static const uint8 EEPROM_KEY_VALUE = 0xAA;

/**********DATA STRUCTURES**********/
static enum ToneType toneConfigurationList[SPEAKER_COUNT][CHANNEL_COUNT_PER_SPEAKER];
    
static struct
{
    uint8 bRadioAndMicKey;
    uint8 bParkKill;
    uint8 bTackSwitch;
    uint8 bHornRing;
    uint8 bDualDelay;
    enum ChannelIndex highestPriorityChannel[SPEAKER_COUNT];
}InputRead;

static struct
{
    enum ToneType previousTone[SPEAKER_COUNT];
    enum ToneType currentTone[SPEAKER_COUNT];
    uint8 bRisingEdge[SPEAKER_COUNT];
    uint8 bDualDelayEnable;
}ToneStatus;

/**********GLOBAL VARIABLES**********/


/**********FUNCTION PROTOTYPES**********/
static void decideTonesToPlay(void);
static uint8 enableSpeakerForSirenTone(uint8 bSpeaker, enum ToneType toneSelection, uint8 bInputEnable, uint8 bDelay);
static uint8 enableSpeakersForAudioTone(uint8 bSpeaker, enum ToneType toneSelection, uint8 bInputEnable);
static enum ChannelIndex getHighestPriorityChannel(uint8 bSpeakerNumber);
static enum ToneType getAlternatingTone(enum ToneType toneSelection);
static uint8 isTrailingTone(enum ToneType thisTone);
static uint8 isAudioTone(enum ToneType thisTone);
static uint8 isCommand(enum ToneType thisTone);
static uint8 isSong(enum ToneType thisTone);
static uint8 getBitIndex(enum BitMask maskNumber);

/**********DEFINED FUNCTIONS**********/
/*******************************************************************************
* Function Name: initializeToneConfigurationList
********************************************************************************
*
* Summary:
*  Sets the configuration list to the tones saved in EEPROM
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void initializeToneConfigurationList(void)
{
    uint8 bHasNoTone = false;  
    uint8 bSpeakerIndex = SPEAKER_1;
    uint8 channelIndex = NO_CHANNEL;   
    uint16 addressIndex = 0;
    
    EEPROM_Start();   
    
    for(bSpeakerIndex = 0; bSpeakerIndex < SPEAKER_COUNT; bSpeakerIndex++)
    {   //Check for indices with no tone written to it
        for(channelIndex = 0; channelIndex < CHANNEL_COUNT_PER_SPEAKER; channelIndex++)
        {
            addressIndex = (uint16)(CHANNEL_COUNT_PER_SPEAKER * bSpeakerIndex + channelIndex);
            if(EEPROM_ReadByte(addressIndex) >= TONE_TYPE_LIST_SIZE)
            {   //Terminate loop after finding first invalid tone
                bHasNoTone = true;
                break;
            }
        }
    }
    
    if((bHasNoTone == true) || (EEPROM_ReadByte(EEPROM_KEY_INDEX) != EEPROM_KEY_VALUE))
    {   //Write to EEPROM 
        EEPROM_UpdateTemperature(); //Optimizes write timings based on temperature reading 
        
        for(bSpeakerIndex = 0; bSpeakerIndex < SPEAKER_COUNT; bSpeakerIndex++)
        {   //Obtain tones from EEPROM to configure channels
            for(channelIndex = 0; channelIndex < CHANNEL_COUNT_PER_SPEAKER; channelIndex++)
            {
                addressIndex = (uint16)(CHANNEL_COUNT_PER_SPEAKER * bSpeakerIndex + channelIndex);
                EEPROM_WriteByte(DEFAULT_CONFIGURATION_LIST[addressIndex], addressIndex);
            }
        }
        
        EEPROM_WriteByte(EEPROM_KEY_VALUE, EEPROM_KEY_INDEX);
    }
    
    for(bSpeakerIndex = 0; bSpeakerIndex < SPEAKER_COUNT; bSpeakerIndex++)
    {   //Obtain tones from EEPROM to configure channels
        for(channelIndex = 0; channelIndex < CHANNEL_COUNT_PER_SPEAKER; channelIndex++)
        {
            addressIndex = (uint16)(CHANNEL_COUNT_PER_SPEAKER * bSpeakerIndex + channelIndex);
            toneConfigurationList[bSpeakerIndex][channelIndex] = EEPROM_ReadByte(addressIndex);
        }
    }
}

/*******************************************************************************
* Function Name: enableToneInputInterrupts
********************************************************************************
*
* Summary:
*   Enables the input interrupts that cannot be activated during Data Link
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void enableToneInputInterrupts(void)
{
    //TackSwitchISR_Start();
    //TackSwitchStatus_InterruptEnable();
    
    //DualDelayISR_Start();
    //DualDelayStatus_InterruptEnable();
    
    //ModeStatusISR_Start();
}

/*******************************************************************************
* Function Name: disableToneInputInterrupts
********************************************************************************
*
* Summary:
*   Disables specific input interrupts that cannot be activated during Data Link
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void disableToneInputInterrupts(void)
{
    //TackSwitchStatus_InterruptDisable();
    //TackSwitchISR_Stop();
    
    //DualDelayStatus_InterruptDisable();
    //DualDelayISR_Stop();
    
    //ModeStatusISR_Stop();
}

/*******************************************************************************
* Function Name: initializeInputReadings
********************************************************************************
*
* Summary:
*  Sets InputRead struct to current input readings at the beginning of the program
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void initializeInputReadings(void)
{
	uint8 speakerIndex = 0;
	
//***    InputRead.bRadioAndMicKey = RadioRebroadcastInput_Read();
    InputRead.bRadioAndMicKey |= MicKeyInput_Read();
    
    
    //InputRead.bParkKill = ParkKillStatus_Read() & 0x01;
    //InputRead.bHornRing = HornRingStatus_Read() & 0x01;
	
	//for(speakerIndex = 0; speakerIndex < SPEAKER_COUNT; speakerIndex++)
	//	InputRead.highestPriorityChannel[speakerIndex] = getHighestPriorityChannel(speakerIndex);
    
    decideTonesToPlay();
}

/*******************************************************************************
* Function Name: processTackSwitchRoutine
********************************************************************************
*
* Summary:
*  Cycles through the tones and configures the tone selection for the specified
*  input, called in TackSwitchISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processTackSwitchRoutine(void)
{
    enum ToneType toneToPlay = NO_TONE;
    uint16 addressIndex = 0;
    uint8 channelIndex = 0;
    uint8 bSpeakerIndex = 0;
    
    //InputRead.bTackSwitch = TackSwitchStatus_Read() & 0x01;
    
    if((!InputRead.bRadioAndMicKey) && (!InputRead.bParkKill))
    {
        if(InputRead.bTackSwitch)
        {
            deactivateManualWail();
	        deactivateAudio();
			disableAudioAndPWM();
        }
        else
        {   //Tack switch is disabled
            EEPROM_UpdateTemperature(); //Optimizes write timings based on temperature reading
            
            for(bSpeakerIndex = 0; bSpeakerIndex < SPEAKER_COUNT; bSpeakerIndex++)
            {   //Speaker 1 addresses range 0x00 to 0x05, Speaker 2 addresses range 0x06 to 0x0B 
                channelIndex = InputRead.highestPriorityChannel[bSpeakerIndex];
                addressIndex = (uint16)(CHANNEL_COUNT_PER_SPEAKER * bSpeakerIndex + channelIndex);
                
                if(channelIndex != NO_CHANNEL)
                {
                    if(toneToPlay == NO_TONE)
                    {   //Gets original tone for that channel as starting tone in the list               
                        toneToPlay = EEPROM_ReadByte(addressIndex);    
                        toneToPlay = (toneToPlay + 1) % TONE_TYPE_LIST_SIZE;  //Increments to next tone in circular list
                        
                        if(toneToPlay == NO_TONE)
                            toneToPlay++;  //Makes sure a tone is always selected
                    }
                    
                    EEPROM_WriteByte(toneToPlay, addressIndex);
					toneConfigurationList[bSpeakerIndex][channelIndex] = toneToPlay;
					ToneStatus.previousTone[bSpeakerIndex] = ToneStatus.currentTone[bSpeakerIndex];
					ToneStatus.currentTone[bSpeakerIndex] = toneToPlay;
					ToneStatus.bRisingEdge[bSpeakerIndex] = true;
                }
            }
            
            decideTonesToPlay();  
        }
    }
}

/*******************************************************************************
* Function Name: processRadioMicKeyRoutine
********************************************************************************
*
* Summary:
*  Updates the siren system for the radio rebroadcast or mic key input change,
*  called in RadioMicKeyISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processRadioMicKeyRoutine(void)
{
	uint8 speakerIndex = 0;
	
//***    InputRead.bRadioAndMicKey = RadioRebroadcastInput_Read() ||  MicKeyInput_Read();
    
    if(InputRead.bRadioAndMicKey)
    {
		deactivateManualWail(); //Deactivate tones and leave one power amp on
        deactivateAudio();
		PowerAmpOutput1_Write(true);
        PowerAmpOutput1_Write(false);
		
		for(speakerIndex = 0; speakerIndex < SPEAKER_COUNT; speakerIndex++)
		{
			stopPWMTone(speakerIndex);
			stopAudioTone(speakerIndex);
            ToneStatus.bRisingEdge[speakerIndex] = false;
		}
    }
	else
		decideTonesToPlay();
}

/*******************************************************************************
* Function Name: processParkKillRoutine
********************************************************************************
*
* Summary:
*  Updates the siren system for the park kill input change, called in ParkKillISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processParkKillRoutine(void)
{
    //InputRead.bParkKill = ParkKillStatus_Read() & 0x01;    
    decideTonesToPlay();
}

/*******************************************************************************
* Function Name: processHornRingRoutine
********************************************************************************
*
* Summary:
*  Updates the siren system for the horn input change, called in HornRingISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processHornRingRoutine(void)
{
    //InputRead.bHornRing = HornRingStatus_Read() & 0x01;
    decideTonesToPlay();
}

/*******************************************************************************
* Function Name: processDualDelayRoutine
********************************************************************************
*
* Summary:
*  Activates delay functionality for the two current tones, called in DualDelayISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processDualDelayRoutine(void)
{
    //InputRead.bDualDelay = DualDelayStatus_Read() & 0x01;
    ToneStatus.bDualDelayEnable = InputRead.bDualDelay;
    decideTonesToPlay();
}

/*******************************************************************************
* Function Name: processToneChangeRoutine
********************************************************************************
*
* Summary:
*  Updates the siren system for the tone input change, called in ModeStatusISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processToneChangeRoutine(void)
{  
    static uint8 previousChannels[SPEAKER_COUNT];
    uint8 currentChannels[SPEAKER_COUNT];
    uint8 changeStatus[SPEAKER_COUNT];
    uint8 changedChannel[SPEAKER_COUNT];
    uint8 speakerIndex = 0;
	uint8 priorityChannel = 0;
    
    //currentChannels[SPEAKER_1] = ModeStatus_Read();
    //currentChannels[SPEAKER_2] = ModeStatus2_Read();
    
    for(speakerIndex = 0; speakerIndex < SPEAKER_COUNT; speakerIndex++)
    {
        changeStatus[speakerIndex] =
            previousChannels[speakerIndex] ^ currentChannels[speakerIndex];
			
		changedChannel[speakerIndex] = getBitIndex(changeStatus[speakerIndex]);
		InputRead.highestPriorityChannel[speakerIndex] = getHighestPriorityChannel(speakerIndex);
		priorityChannel = InputRead.highestPriorityChannel[speakerIndex];
			
		if(changeStatus[speakerIndex] & currentChannels[speakerIndex])
			ToneStatus.bRisingEdge[speakerIndex] = true;
		else
        {
            if((priorityChannel == NO_CHANNEL) || ((changedChannel[speakerIndex] != NO_CHANNEL) && 
                (priorityChannel < changedChannel[speakerIndex])))
			    ToneStatus.bRisingEdge[speakerIndex] = false;
        }
		
        previousChannels[speakerIndex] = currentChannels[speakerIndex];
		ToneStatus.previousTone[speakerIndex] = ToneStatus.currentTone[speakerIndex];	
		
		if(priorityChannel != NO_CHANNEL)
			ToneStatus.currentTone[speakerIndex] = toneConfigurationList[speakerIndex][priorityChannel];
		else
			ToneStatus.currentTone[speakerIndex] = NO_TONE;
    }
	
	decideTonesToPlay();
}

/*******************************************************************************
* Function Name: setTonesWithCommunication
********************************************************************************
*
* Summary:
*   Called during Data Link to update the tone using the data from the Controller
*
* Parameters:  
*   firstTone: The tone selection for Speaker 1
*   secondTone: The tone selection for Speaker 2
*   bDualDelay: The Dual Delay status from the Controller
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
uint8 setTonesWithCommunication(enum ToneType firstTone, enum ToneType secondTone,
                                uint8 bDualDelay)
{
    uint8 speakerIndex = 0;
    uint8 bDualDelayChange = false;
    
    if((firstTone < NO_TONE) || (firstTone > TEST_TONE))
        return false;
    
    if((secondTone < NO_TONE) || (secondTone > TEST_TONE))
        return false;
    
    if((bDualDelay != true) && (bDualDelay != false))
        return false;
    
    ToneStatus.previousTone[SPEAKER_1] = ToneStatus.currentTone[SPEAKER_1];
    ToneStatus.previousTone[SPEAKER_2] = ToneStatus.currentTone[SPEAKER_2];
    ToneStatus.currentTone[SPEAKER_1] = firstTone;
    ToneStatus.currentTone[SPEAKER_2] = secondTone;
    
    if(bDualDelay != ToneStatus.bDualDelayEnable)
        bDualDelayChange = true;
    
    ToneStatus.bDualDelayEnable = bDualDelay;
    
    for(speakerIndex = 0; speakerIndex < SPEAKER_COUNT; speakerIndex++)
    {
        if((ToneStatus.previousTone[speakerIndex] == NO_TONE) &&
            (ToneStatus.currentTone[speakerIndex] != NO_TONE))
            ToneStatus.bRisingEdge[speakerIndex] = true;
        else if((ToneStatus.previousTone[speakerIndex] != NO_TONE) &&
            (ToneStatus.currentTone[speakerIndex] == NO_TONE))
            ToneStatus.bRisingEdge[speakerIndex] = false;
    }
    
    if((ToneStatus.previousTone[SPEAKER_1] != ToneStatus.currentTone[SPEAKER_1]) ||
        (ToneStatus.previousTone[SPEAKER_2] != ToneStatus.currentTone[SPEAKER_2]) ||
        (bDualDelayChange == true))
        decideTonesToPlay();
    
    return true;
}

/*******************************************************************************
* Function Name: disableAudioAndPWM
********************************************************************************
*
* Summary:
*   Disables the DAC and PWM for both speakers, typically called before the Power
*   Amps are disabled for a clear shut down
*
* Parameters: 
*   None
*
* Return:
*   None
*
*******************************************************************************/
void disableAudioAndPWM(void)
{
	stopPWMTone(SPEAKER_1);
    stopPWMTone(SPEAKER_2);
    stopAudioTone(SPEAKER_1);
    stopAudioTone(SPEAKER_2);
}

/*******************************************************************************
* Function Name: disableBothSpeakers
********************************************************************************
*
* Summary:
*   Disables the Power Amps and updates the PWM and DAC status to play no tone
*   for both speakers, typically called after the DAC and PWM are disabled.
*
* Parameters: 
*   None
*
* Return:
*   None
*
*******************************************************************************/
void disableBothSpeakers(void)
{
	deactivateManualWail();
	deactivateAudio();
	PowerAmpOutput1_Write(false);
    playAudioTone(SPEAKER_1, NO_TONE, false);
    playAudioTone(SPEAKER_2, NO_TONE, false);
    playPWMTone(SPEAKER_1, NO_TONE, false, false);
    playPWMTone(SPEAKER_2, NO_TONE, false, false);
}

/*******************************************************************************
* Function Name: decideTonesToPlay
********************************************************************************
*
* Summary:
*  The state machine that determines the tone outcome for each speaker.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
static void decideTonesToPlay(void)
{
	static uint8 bToneChangeOnHornRing = false;
    
    disableAudioAndPWM();
    
    if(InputRead.bRadioAndMicKey)
        return;	
    
	if(ToneStatus.currentTone[SPEAKER_1] != NO_TONE)
	{
		if(isAudioTone(ToneStatus.currentTone[SPEAKER_1]))
		{
			if(isSong(ToneStatus.currentTone[SPEAKER_1]))
			{
				if(ToneStatus.bRisingEdge[SPEAKER_1])	//Plays BAD BOYS	
					enableSpeakersForAudioTone(SPEAKER_1, ToneStatus.currentTone[SPEAKER_1], true);
				else	//Plays NO TONE
					disableBothSpeakers();
				
			}
			else	//Plays ECTO OR COMMAND 
				enableSpeakersForAudioTone(SPEAKER_1, ToneStatus.currentTone[SPEAKER_1], true);
		}
		else
		{	
            if(isAudioTone(ToneStatus.currentTone[SPEAKER_2]))
    		{
    			if(isSong(ToneStatus.currentTone[SPEAKER_2]))
    			{
    				if(ToneStatus.bRisingEdge[SPEAKER_2])	//Plays BAD BOYS	
    					enableSpeakersForAudioTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2], true);
    				else	//Plays NO TONE
    					disableBothSpeakers();
    				
    			}
    			else	//Plays ECTO OR COMMAND 
    				enableSpeakersForAudioTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2], true);
    		}
			else if(InputRead.bParkKill)	//Plays NO TONE
				disableBothSpeakers();
			else if(InputRead.bHornRing)
			{	//Plays NO TONE
				bToneChangeOnHornRing = !bToneChangeOnHornRing;
				disableBothSpeakers();
			}
			else if(bToneChangeOnHornRing)
			{	//Plays SPEAKER 1 SIREN TONE
				enableSpeakerForSirenTone(SPEAKER_1, getAlternatingTone(ToneStatus.currentTone[SPEAKER_1]), 
                    true, ToneStatus.bDualDelayEnable);
				
				if(ToneStatus.currentTone[SPEAKER_2] != NO_TONE)
					enableSpeakerForSirenTone(SPEAKER_2, getAlternatingTone(ToneStatus.currentTone[SPEAKER_2]), 
                        true, ToneStatus.bDualDelayEnable);
				else
                {
                    PowerAmpOutput1_Write(false);
                    enableSpeakerForSirenTone(SPEAKER_2, NO_TONE, false, ToneStatus.bDualDelayEnable);
                }
			}
			else
			{	//Plays SPEAKER 1 SIREN TONE
				enableSpeakerForSirenTone(SPEAKER_1, ToneStatus.currentTone[SPEAKER_1],
                    true, ToneStatus.bDualDelayEnable);
				
				if(ToneStatus.currentTone[SPEAKER_2] != NO_TONE)
					enableSpeakerForSirenTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2],
                        true, ToneStatus.bDualDelayEnable);
				else
                {
				    PowerAmpOutput1_Write(false);
                    enableSpeakerForSirenTone(SPEAKER_2, NO_TONE, false, ToneStatus.bDualDelayEnable);
                }
			}
		}
	}
	else if(ToneStatus.currentTone[SPEAKER_2] != NO_TONE)
	{
		if(isAudioTone(ToneStatus.currentTone[SPEAKER_2]))
		{
			if(isSong(ToneStatus.currentTone[SPEAKER_2]))
			{
				if(ToneStatus.bRisingEdge[SPEAKER_2])	//Plays BAD BOYS	
					enableSpeakersForAudioTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2], true);
				else	//Plays NO TONE
					disableBothSpeakers();
				
			}
			else	//Plays ECTO OR COMMAND 
				enableSpeakersForAudioTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2], true);
		}
		else
		{	
			if(InputRead.bParkKill)	//Plays NO TONE
				disableBothSpeakers();
			else if(InputRead.bHornRing)
			{	//Plays NO TONE
				bToneChangeOnHornRing = !bToneChangeOnHornRing;
				disableBothSpeakers();
			}
			else if(bToneChangeOnHornRing)
			{	//Plays SPEAKER 2 SIREN TONE
				PowerAmpOutput1_Write(false);
                enableSpeakerForSirenTone(SPEAKER_1, NO_TONE, false, ToneStatus.bDualDelayEnable);
				enableSpeakerForSirenTone(SPEAKER_2, getAlternatingTone(ToneStatus.currentTone[SPEAKER_2]),
                    true, InputRead.bDualDelay);
			}
			else
			{	//Plays SPEAKER 2 SIREN TONE
				PowerAmpOutput1_Write(false);
                enableSpeakerForSirenTone(SPEAKER_1, NO_TONE, false, ToneStatus.bDualDelayEnable);
				enableSpeakerForSirenTone(SPEAKER_2, ToneStatus.currentTone[SPEAKER_2],
                    true, InputRead.bDualDelay);
			}
		}
	}
	else
	{	
        if(InputRead.bParkKill)
            disableBothSpeakers();
        else
        {
    		if(InputRead.bHornRing)
    		{	//Plays HORN
    			bToneChangeOnHornRing = false;
    			deactivateManualWail();
    			enableSpeakerForSirenTone(SPEAKER_1, HORN, false, false);
    			enableSpeakerForSirenTone(SPEAKER_2, HORN, false, false);
    		}
    		else if(isTrailingTone(ToneStatus.previousTone[SPEAKER_1]))
    		{
    			if(isAudioTone(ToneStatus.previousTone[SPEAKER_1]))	//Plays ECTO or COMMAND	
    				enableSpeakersForAudioTone(SPEAKER_1, ToneStatus.previousTone[SPEAKER_1], false);
    			else	//Plays MANUAL WAIL
    				enableSpeakerForSirenTone(SPEAKER_1, ToneStatus.previousTone[SPEAKER_1], false, false);	
                
                ToneStatus.previousTone[SPEAKER_1] = NO_TONE;
                bToneChangeOnHornRing = false;
    		}
    		else if(isTrailingTone(ToneStatus.previousTone[SPEAKER_2]))
    		{
    			if(isAudioTone(ToneStatus.previousTone[SPEAKER_2]))	//Plays ECTO or COMMAND	
    				enableSpeakersForAudioTone(SPEAKER_2, ToneStatus.previousTone[SPEAKER_2], false);	
    			else	//Plays MANUAL WAIL	
    				enableSpeakerForSirenTone(SPEAKER_2, ToneStatus.previousTone[SPEAKER_2], false, false);	
                    
                ToneStatus.previousTone[SPEAKER_2] = NO_TONE;
                bToneChangeOnHornRing = false;
    		}
    		else	//Plays NO TONE
            {
                bToneChangeOnHornRing = false;
    			disableBothSpeakers();
            }
        }
	}
}

/*******************************************************************************
* Function Name: enableSpeakerForSirenTone
********************************************************************************
*
* Summary:
*   Procedure for enabling a siren tone for the selected speaker
*
* Parameters: 
*   bSpeaker: Speaker selection (SPEAKER_1 or SPEAKER_2)
*   toneSelection: The tone to play
*   bInputEnable: The current input status
*   bDelay: The Dual Delay status
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 enableSpeakerForSirenTone(uint8 bSpeaker, enum ToneType toneSelection,
                                    uint8 bInputEnable, uint8 bDelay)
{
	if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    if((toneSelection < NO_TONE) || (toneSelection > TEST_TONE))
        return false;
    
    if((bInputEnable != true) && (bInputEnable != false))
        return false;
    
    deactivateAudio();
    playAudioTone(bSpeaker, NO_TONE, false);
	playPWMTone(bSpeaker, toneSelection, bInputEnable, bDelay);
	
    if(toneSelection != NO_TONE)
    {
    	//if(bSpeaker)
    		PowerAmpOutput1_Write(true);
    	//else
    	//	PowerAmpOutput1_Write(true);
    }
        
    return true;
}

/*******************************************************************************
* Function Name: enableSpeakersForAudioTone
********************************************************************************
*
* Summary:
*   Procedure for enabling an audio tone for the selected speaker
*
* Parameters: 
*   bSpeaker: Speaker selection (SPEAKER_1 or SPEAKER_2)
*   toneSelection: The tone to play
*   bInputEnable: The current input status
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 enableSpeakersForAudioTone(uint8 bSpeaker, enum ToneType toneSelection,
                                        uint8 bInputEnable)
{
	if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    if((toneSelection < WAIL) || (toneSelection > TEST_TONE))
        return false;
    
    if((bInputEnable != true) && (bInputEnable != false))
        return false;
    
    deactivateManualWail();
    playPWMTone(bSpeaker, NO_TONE, false, false);
	playAudioTone(bSpeaker, toneSelection, bInputEnable);
	PowerAmpOutput1_Write(true);
    
    return true;
}

/*******************************************************************************
* Function Name: getHighestPriorityInput
********************************************************************************
*
* Summary:
*  Determines the active tone with the highest priority
*
* Parameters: 
*   bSpeakerNumber - The speaker selection for the input reading
*
* Return:
*   The active tone mode with the highest priority
*
*******************************************************************************/
static enum ChannelIndex getHighestPriorityChannel(uint8 bSpeakerNumber)
{
    uint8 modeStatusByte = 0;
    
    if((bSpeakerNumber != SPEAKER_1) && (bSpeakerNumber != SPEAKER_2))
        return NO_CHANNEL;
    
    //if(bSpeakerNumber)
    //    modeStatusByte = ModeStatus2_Read();
    //else
    //    modeStatusByte = ModeStatus_Read();
    
    if(modeStatusByte & 0x20)
        return CHANNEL_6;
    if(modeStatusByte & 0x10)
        return CHANNEL_5;
    if(modeStatusByte & 0x08)
        return CHANNEL_4;
    if(modeStatusByte & 0x04)
        return CHANNEL_3;    
    if(modeStatusByte & 0x02)
        return CHANNEL_2;
    if(modeStatusByte & 0x01)
        return CHANNEL_1;
    
    return NO_CHANNEL;
}

/*******************************************************************************
* Function Name: getAlternatingTone
********************************************************************************
*
* Summary:
*   Gets the 2nd tone to play during toggling with the horn
*
* Parameters: 
*   toneSelection: The first tone to play during toggling
*
* Return:
*   The alternating tone (or the same tone if no horn capability)
*
*******************************************************************************/
static enum ToneType getAlternatingTone(enum ToneType toneSelection)
{
	if((toneSelection == NO_TONE) || isAudioTone(toneSelection) || (toneSelection == TEST_TONE))
		return toneSelection;
	
	if((toneSelection == MECHANICAL) || (toneSelection == PCALL_FAST))
		return PHASER;
	
	if(toneSelection == PHASER_YELP)
		return HORN_PHASER;
	
	return (toneSelection + 1);
}

/*******************************************************************************
* Function Name: isTrailingTone
********************************************************************************
*
* Summary:
*   Determines if the given tone has the trailing effect
*
* Parameters: 
*   thisTone: The tone to check
*
* Return:
*   TRUE if trailing tone, FALSE if not trailing tone or invalid input
*
*******************************************************************************/
static uint8 isTrailingTone(enum ToneType thisTone)
{
    if((thisTone == MANUAL_WAIL) || (thisTone == ECTOSIREN) || isCommand(thisTone))
        return true;
    
    return false;
}

/*******************************************************************************
* Function Name: isAudioTone
********************************************************************************
*
* Summary:
*   Determines if the given tone is an audio tone
*
* Parameters: 
*   thisTone: The tone to check
*
* Return:
*   TRUE if audio tone, FALSE if not audio tone or invalid input
*
*******************************************************************************/
static uint8 isAudioTone(enum ToneType thisTone)
{
    if((thisTone == ECTOSIREN) || isSong(thisTone) || isCommand(thisTone))
        return true;
    
    return false;
}

/*******************************************************************************
* Function Name: isCommand
********************************************************************************
*
* Summary:
*   Determines if the given tone is a command
*
* Parameters: 
*   thisTone: The tone to check
*
* Return:
*   TRUE if a command, FALSE if not a command or invalid input
*
*******************************************************************************/
static uint8 isCommand(enum ToneType thisTone)
{
    if((thisTone >= MOVE_OUT) && (thisTone <= REMAIN_WINDOW_DOWN))
        return true;
    
    return false;
}

/*******************************************************************************
* Function Name: isSong
********************************************************************************
*
* Summary:
*   Determines if the given tone is a song
*
* Parameters: 
*   thisTone: The tone to check
*
* Return:
*   TRUE if a song, FALSE if not a song or invalid input
*
*******************************************************************************/
static uint8 isSong(enum ToneType thisTone)
{
    if(thisTone == COPS_SONG)
        return true;
    
    return false;
}

/*******************************************************************************
* Function Name: getBitIndex
********************************************************************************
*
* Summary:
*  Computes the index of a byte based on the mask given. 7 is the most significant bit.
*
* Parameters:
*  maskNumber: An 8-bit value with a single bit being set to 1
*
* Return:
*  The index of the set bit ranging 0 - 7
*
*******************************************************************************/
static uint8 getBitIndex(enum BitMask maskNumber)
{
	uint8 indexResult = 0;
	
	switch(maskNumber)
	{
		case BIT0:
			indexResult = 0;
			break;
		case BIT1:
			indexResult = 1;
			break;
		case BIT2:
			indexResult = 2;
			break;
		case BIT3:
			indexResult = 3;
			break;
		case BIT4:
			indexResult = 4;
			break;
		case BIT5:
			indexResult = 5;
			break;
		default:
			indexResult = NO_CHANNEL;
			break;
	}
	
	return indexResult;
}
