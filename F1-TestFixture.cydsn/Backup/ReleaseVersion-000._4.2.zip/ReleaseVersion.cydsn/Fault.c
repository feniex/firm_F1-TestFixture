/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "Fault.h"
#include "Tones.h"
#include "DACaudio.h"

/**********DEFINED CONSTANTS**********/
static const uint8 WAIT_TIME_IN_HALF_SECONDS = 10;

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/
static uint8 bOverloadFlag = false;

/**********FUNCTION PROTOTYPES**********/

/**********DEFINED FUNCTIONS**********/

/*******************************************************************************
* Function Name: isThereOverload
********************************************************************************
*
* Summary:
*  Returns the boolean for overload detection
*
* Parameters:  
*   None
*
* Return:
*   The boolean for overload detection
*
*******************************************************************************/
uint8 isThereOverload(void)
{   
    return bOverloadFlag;
}

/*******************************************************************************
* Function Name: processOverloadRoutine
********************************************************************************
*
* Summary:
*  Waits for overload signal to clear before restarting the siren system,
*  called in main
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processOverloadRoutine(void)
{
    uint8 index = 0;
    CyGlobalIntDisable;
    
    while(!OverloadInput1_Read() || !OverloadInput2_Read())
    {   //Cannot use do-while loop to prevent cool-down at startup
        PowerAmpOutput1_Write(false);
        //PowerAmpOutput1_Write(false);
        for(index = 0; index < WAIT_TIME_IN_HALF_SECONDS; index++)
        {
            CyWdtClear();
            LEDoutput_Write(true);
            CyDelay(250);
            LEDoutput_Write(false);
            CyDelay(250);
        }
    }
    
    bOverloadFlag = false;   
    RadioMicKeyISR_ClearPending();   
    //ParkKillISR_ClearPending(); 
    //TackSwitchISR_ClearPending();
    //DualDelayISR_ClearPending();
    //HornRingISR_ClearPending();
    //ModeStatusISR_ClearPending();
    CyGlobalIntEnable;
}

/*******************************************************************************
* Function Name: deactivatePoweredFunctions
********************************************************************************
*
* Summary:
*  Turns off PWM, power amps, and tone due to overload detection, called in
*  OverloadISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void deactivatePoweredFunctions(void)
{
    CyGlobalIntDisable;    
    PowerAmpOutput1_Write(false);
    //PowerAmpOutput1_Write(false);
    stopPWMTone(SPEAKER_1);
    stopPWMTone(SPEAKER_2);
    stopAudioTone(SPEAKER_1);
    stopAudioTone(SPEAKER_2);
    bOverloadFlag = true;
}

/* [] END OF FILE */
