/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

const unsigned char RELAY_VERSION_MAJOR = 0;
const unsigned char RELAY_VERSION_MINOR = 1;
const unsigned char RELAY_VERSION_PATCH = 4;

/********************Version Changes***************************
* V0.1.0 - 7-8-20
* - Version number was added
* - Siren Streaming test code was commented out
* - Test code was added to manually play both siren amps
* - Pins were pinned out to match REV02
*    - Amp_EN was consolidated to one pin
* - Overload debounce was changed from 100Hz to 20Hz
* - USBFS module was removed (was obsolete and not compiling, also was unsused)
*
* V0.1.1 - 8-6-20
* - Removed RadioRebroadcast_Input pin and associated code
* - Gave control back to the DL packet coming straight from the controller SOM
*
* V0.1.2 - 8-10-20
*   - Changed the Rx packet header from 'V' to 'S' and I am not receiving Siren commands from the controller SOM
*   - Changed the baud rate from 115200 to 230400
*
* Working toward V0.1.3 - 8-17-20
*   - Changed the overload debounce back to 100Hz
*   - ***Need to look into the siren playing through one side only
*   - ***Need to look into audio tones not playing - kyle said he knew whats up here
*
* Working toward V0.1.4 - 10-16-20
*   - Updated the RRB_En to be strong drive.
*   - Updated the packet size to match the F1 Packet definition. This makes the siren packet be the same as DataLink.
*   - ***Need to look into the siren playing through one side only
*   - ***Need to look into audio tones not playing - kyle said he knew whats up here
*
* Need To Do
*   ***Clean up resource block page and rename pins appropriately
*   ***Test overall functionality in system and update to version V1.0.0
*
***********************************************/

/**********PREPROCESSOR DIRECTIVES**********/
#include <project.h>

#include "CommonVariables.h"
#include "Fault.h"
#include "SirenState.h"
#include "CommManager.h"

/**********DEFINED CONSTANTS**********/

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
static void initializePeripherals(void);

/**********DEFINED FUNCTIONS**********/

int main()
{
    initializePeripherals();
    CyGlobalIntEnable; /* Enable global interrupts. */

    initializeInputReadings();
    
//********************Audio Streaming******************************   
//    AMux1_FastSelect(DAC_MODE);                           //*** Test Code - Streams audio - handled in audio byte rx interrupt - reads byte and puts it out on DAC
//    AMux2_FastSelect(DAC_MODE);
//    
//    PGA_1_Start();   
//    VDAC8_1_Start();
//    
//    PGA_2_Start();   
//    VDAC8_2_Start();
//**************************************************

//**************************************************
    //setTonesWithCommunication(1,1,1);                       // *** Test Code - Play 'Wail' on both amps with DualDelay, RRB testing
    //RadioRebroadcast_EN_Write(1);
    //PowerAmpOutput1_Write(1);
//**************************************************

    for(;;)
    {     
        while(!isThereOverload())
        {   //No overload, so allow any ISRs to process
            CyWdtClear();
            CyDelay(1);
        }
        processOverloadRoutine();
    }
}

/*******************************************************************************
* Function Name: initializePeripherals
********************************************************************************
*
* Summary:
*  Sets up the watchdog timer, disables, power amplifiers, and enables all ISRs
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
static void initializePeripherals(void)
{
    CyWdtStart(CYWDT_1024_TICKS, CYWDT_LPMODE_NOCHANGE);    //2.048 - 3.072 seconds
    PowerAmpOutput1_Write(false);
    //PowerAmpOutput1_Write(false);
    
    LED_ISR_Start();    //Start LED heartbeat
    LED_Timer_Start();
    
    while(!OverloadInput1_Read() || !OverloadInput2_Read()){};  //Used to catch first overload
    initializeToneConfigurationList();                          //Gets tones from EEPROM
    CyDelay(250); //Delay needed to eliminate power amp starting prematurely
    
    AMux1_Start();              //Initialize both multiplexers
    AMux1_FastSelect(PWM_MODE);
    AMux2_Start();
    AMux2_FastSelect(PWM_MODE);
    
    PWM1_ISR_Start();       //Initialize interrupts for PWM tones
    PWM2_ISR_Start();
    PWMtimer1_ISR_Start();  
    PWMtimer2_ISR_Start();
    
    SPIM_Start();           //Initialize interrupts for DAC tones
    DAC1_ISR_Start();
    
    UART_TimerISR_Start();
    UART_ISR_Start();
    UART_Start();
    
    ISR_UART_Audio_Start();      
    UART_Audio_Start();
    
    OverloadISR_Start();     
    RadioMicKeyISR_Start();
    
    //ParkKillISR_Start();   //Initialize interrupts for all inputs
    //ParkKillStatus_InterruptEnable();
    
    //HornRingISR_Start();
    //HornRingStatus_InterruptEnable();
    
    enableToneInputInterrupts();
}

void sendVersionPacket(void)
{
    static uint8 iterator = 0;
    
    UART_WriteTxData(0x7E);
    UART_WriteTxData('H');
    UART_WriteTxData(RELAY_VERSION_MAJOR);
    UART_WriteTxData(RELAY_VERSION_MINOR);
    UART_WriteTxData(RELAY_VERSION_PATCH);
    UART_WriteTxData(0x0D);
    UART_WriteTxData(0x0A);
    
    UART_WriteTxData(0x7E);
    UART_WriteTxData('H');
    UART_WriteTxData(RELAY_VERSION_MAJOR);
    UART_WriteTxData(RELAY_VERSION_MINOR);
    UART_WriteTxData(RELAY_VERSION_PATCH);
    UART_WriteTxData(0x0D);
    UART_WriteTxData(0x0A);
    
    UART_WriteTxData(0x7E);
    UART_WriteTxData('H');
    UART_WriteTxData(RELAY_VERSION_MAJOR);
    UART_WriteTxData(RELAY_VERSION_MINOR);
    UART_WriteTxData(RELAY_VERSION_PATCH);
    UART_WriteTxData(0x0D);
    UART_WriteTxData(0x0A);
    
    UART_WriteTxData(0x7E);
    UART_WriteTxData('H');
    UART_WriteTxData(RELAY_VERSION_MAJOR);
    UART_WriteTxData(RELAY_VERSION_MINOR);
    UART_WriteTxData(RELAY_VERSION_PATCH);
    UART_WriteTxData(0x0D);
    UART_WriteTxData(0x0A);
    
    UART_WriteTxData(0x7E);
    UART_WriteTxData('H');
    UART_WriteTxData(RELAY_VERSION_MAJOR);
    UART_WriteTxData(RELAY_VERSION_MINOR);
    UART_WriteTxData(RELAY_VERSION_PATCH);
    UART_WriteTxData(0x0D);
    UART_WriteTxData(0x0A);
}

/* [] END OF FILE */
