/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef FILE_DECODE_H_
#define FILE_DECODE_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
    
/**********DEFINED CONSTANTS**********/

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
uint8 getChannelCount(void);
uint8 getBytesPerSample(void);
uint32 getSamplingRate(void);
uint32 getDataSize(void);
uint8 getNextWaveData(uint32 address);
uint8 processHeaderData(enum ToneType songChoice);
    
#endif

/* [] END OF FILE */