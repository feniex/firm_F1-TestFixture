/* ========================================
 *
 * Copyright FENIEX INDUSTRIES, 2016
 * 200W SIREN
 *
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********CHANGE LOG**********/


/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "SirenState.h"
#include "CommManager.h"

#define HEADER_BYTE_COUNT       2
#define EOP_BYTE_COUNT          2

#define HEADER_START_INDEX      0
#define PAYLOAD_START_INDEX     HEADER_BYTE_COUNT

#define MAX_PAYLOAD_BYTE_COUNT  5
#define PACKET_TYPE_COUNT       2

/**********DEFINED CONSTANTS**********/
enum DataType
{ 
    SIREN_INPUTS,
    VOICE_DATA,
};

enum PacketState
{
    HEADER_STATE,
    PAYLOAD_STATE,
    EOP_STATE
};

static const uint8 START_BYTE = 0xAA;
static const uint8 STOP_BYTE = 0x55;
static const uint8 INITIAL_DAC_VALUE = 128;
static const uint8 TIMER_LIMIT_IN_TEN_MILLISECONDS = 250;

/**********DATA STRUCTURES**********/
typedef struct
{
    const uint8 HEADER_BYTE;
    const uint8 PACKET_TYPE;
    const uint8 PAYLOAD_SIZE;
    const uint8 EOP_CARRIAGE_RETURN;
    const uint8 EOP_LINE_FEED;
}Packet;

static Packet PacketList[PACKET_TYPE_COUNT] = 
{
    {'~', 'S', 3, '\r', '\n'},
    {'~', '?', 3, '\r', '\n'},                      //*** This needs work eventually
};

/**********GLOBAL VARIABLES**********/
static uint8 bVoiceStreamEnabled = false;
static uint8 tenMilliSecondsCount = 0;

/**********LOCAL FUNCTION PROTOTYPES**********/
static void detectPacket(uint8 dataByte);
static void startVoiceStreamMode(void);
static void stopVoiceStreamMode(void);

/**********DEFINED GLOBAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: processByteReceivedHandler
********************************************************************************
*
* Summary:
*  Triggers when a byte is received in UART_Audio, called in ISR_UART_Audio().
*  
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processByteReceivedHandler_UART_Audio(void)
{
    uint8 dataByte = 0;
    
//    UART_Timer_Stop();
//    disableToneInputInterrupts();
//    tenMilliSecondsCount = 0;
    
    
// *** Need to disable everything else and give voice stream priority
// *** Need to service timeout stuff???
    
    do
    {
        dataByte = UART_Audio_GetChar();
        
        VDAC8_1_SetValue(dataByte);
        VDAC8_2_SetValue(dataByte);
       
    }while(UART_Audio_ReadRxStatus() & UART_Audio_RX_STS_FIFO_NOTEMPTY);
    
//    VDAC8_1_SetValue(dataByte);
    
//    UART_Timer_Start();
}


/*******************************************************************************
* Function Name: processByteReceivedHandler
********************************************************************************
*
* Summary:
*  Triggers when a byte is received in UART, called in UART_ISR(). If in voice
*  stream mode, the byte is sent directly to the DAC.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processByteReceivedHandler(void)
{
    uint8 dataByte = 0;
    
    UART_Timer_Stop();
    disableToneInputInterrupts();
    tenMilliSecondsCount = 0;
    
    static uint8 testbuffer[100];
    static uint8 testbuffer_count = 0;
    
    do
    {
        dataByte = UART_GetChar();
        
        
        testbuffer[testbuffer_count] = dataByte;
        testbuffer_count++;
        if(testbuffer_count >= 100)
            testbuffer_count = 0;
        
        
//        if(bVoiceStreamEnabled)
//        {   
//            VDAC8_1_SetValue(dataByte);
//            VDAC8_2_SetValue(dataByte);
//        }
//        
        detectPacket(dataByte);
        
    }while(UART_ReadRxStatus() & UART_RX_STS_FIFO_NOTEMPTY);
    
    UART_Timer_Start();
}

/*******************************************************************************
* Function Name: processLED_TimerRoutine
********************************************************************************
*
* Summary:
*  Toggles the LED every second, called in LED_ISR().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processLED_TimerRoutine(void)
{
    static uint8 bSwitch = false;
    
    LED_Timer_ReadStatusRegister();
    
    bSwitch = !bSwitch;
    LEDoutput_Write(bSwitch);
}



/*******************************************************************************
* Function Name: processCommTimeoutRoutine
********************************************************************************
*
* Summary:
*  Starts to count when UART has not received data for more than a second. After
*   reaching the timer limit, the routine reenables the siren inputs and stops
*   the timer. Called in UART_TimerISR().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processCommTimeoutRoutine(void)
{
    UART_Timer_ReadStatusRegister();
    
    if(tenMilliSecondsCount < TIMER_LIMIT_IN_TEN_MILLISECONDS)
        tenMilliSecondsCount++;
    else
    {
        tenMilliSecondsCount = 0;
        disableAudioAndPWM();
        disableBothSpeakers();
        enableToneInputInterrupts();
        UART_Timer_Stop();
    }
}

/**********DEFINED LOCAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: detectPacket
********************************************************************************
*
* Summary:
*  Determines if the incoming byte belongs to a valid packet. If the packet is for
*  for starting voice stream, voice stream mode will be activated.
*
* Parameters:
*  dataByte: The byte to check
*
* Return:
*  None.
*
*******************************************************************************/
static void detectPacket(uint8 dataByte)
{
    static uint8 packet[MAX_PAYLOAD_BYTE_COUNT+HEADER_BYTE_COUNT+EOP_BYTE_COUNT];   
    static enum PacketState currentState = HEADER_STATE;
    static enum DataType currentType = SIREN_INPUTS;
    static uint8 currentPacketIndex = HEADER_START_INDEX;
    
    switch(currentState)
    {
        case HEADER_STATE:
            if((currentPacketIndex == HEADER_START_INDEX) && ((dataByte == PacketList[VOICE_DATA].HEADER_BYTE) ||
                (dataByte == PacketList[SIREN_INPUTS].HEADER_BYTE)))
            {
                packet[currentPacketIndex] = dataByte;
                currentPacketIndex++;
            }
            else if((currentPacketIndex == (HEADER_START_INDEX+1)) && ((dataByte == PacketList[VOICE_DATA].PACKET_TYPE) ||
                (dataByte == PacketList[SIREN_INPUTS].PACKET_TYPE)))
            {
                packet[currentPacketIndex] = dataByte;
                currentPacketIndex++;
                currentState = PAYLOAD_STATE;
                
                if(dataByte == PacketList[VOICE_DATA].PACKET_TYPE)
                    currentType = VOICE_DATA;
                else
                    currentType = SIREN_INPUTS;
            }
            else
            {
                currentPacketIndex = HEADER_START_INDEX;
                currentType = SIREN_INPUTS;
            }
            break;
            
        case PAYLOAD_STATE:
            packet[currentPacketIndex] = dataByte;
            currentPacketIndex++;
            
            if(currentPacketIndex >= (PAYLOAD_START_INDEX + PacketList[currentType].PAYLOAD_SIZE))
                currentState = EOP_STATE;
            break;   
            
        case EOP_STATE:
            if((currentPacketIndex == (PAYLOAD_START_INDEX + PacketList[currentType].PAYLOAD_SIZE)) &&
                (dataByte == PacketList[currentType].EOP_CARRIAGE_RETURN))
            {
                packet[currentPacketIndex] = dataByte;
                currentPacketIndex++;
            }
            else if((currentPacketIndex == (PAYLOAD_START_INDEX + PacketList[currentType].PAYLOAD_SIZE + 1)) &&
                (dataByte == PacketList[currentType].EOP_LINE_FEED))
            {
                packet[currentPacketIndex] = dataByte;
                
                if(currentType == VOICE_DATA)
                { 
                    if(packet[PAYLOAD_START_INDEX] == START_BYTE)
                    {
                        bVoiceStreamEnabled = true;
                        startVoiceStreamMode();
                    }
                    else
                    {
                        bVoiceStreamEnabled = false;
                        stopVoiceStreamMode();
                    }
                }
                else if(currentType == SIREN_INPUTS)
                    setTonesWithCommunication(packet[PAYLOAD_START_INDEX], 
                        packet[PAYLOAD_START_INDEX + 1], packet[PAYLOAD_START_INDEX + 2]);
                
                currentPacketIndex = HEADER_START_INDEX;
                currentState = HEADER_STATE;
                currentType = SIREN_INPUTS;
            }
            else
            {
                currentPacketIndex = HEADER_START_INDEX;
                currentState = HEADER_STATE;
                currentType = SIREN_INPUTS;
            }
            break;
    }
}

/*******************************************************************************
* Function Name: startVoiceStreamMode
********************************************************************************
*
* Summary:
*  Enables DACs and Power Amps for voice stream.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
static void startVoiceStreamMode(void)
{
    DACtimer1_Stop();
    DACtimer2_Stop();
    
    AMux1_FastSelect(DAC_MODE);
    AMux2_FastSelect(DAC_MODE);
    
    PGA_1_Start();   
    VDAC8_1_Start();
    VDAC8_1_SetValue(INITIAL_DAC_VALUE);
    
    PGA_2_Start();   
    VDAC8_2_Start();
    VDAC8_2_SetValue(INITIAL_DAC_VALUE);
    
    PowerAmpOutput1_Write(true);
    //PowerAmpOutput1_Write(true);
}

/*******************************************************************************
* Function Name: stopVoiceStreamMode
********************************************************************************
*
* Summary:
*  Disables DACs and Power Amps for voice stream.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
static void stopVoiceStreamMode(void)
{
    PowerAmpOutput1_Write(false);
    //PowerAmpOutput1_Write(false);
    
    VDAC8_1_SetValue(INITIAL_DAC_VALUE);
    VDAC8_1_Stop();
    PGA_1_Stop();
    
    VDAC8_2_SetValue(INITIAL_DAC_VALUE);
    VDAC8_2_Stop();
    PGA_2_Stop();
}

/* [] END OF FILE */
