/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef FAULT_H_
#define FAULT_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include <project.h>
    
/**********DEFINED CONSTANTS**********/

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
uint8 isThereOverload(void);
void processOverloadRoutine(void);
void deactivatePoweredFunctions(void);

#endif
/* [] END OF FILE */
