/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef DAC_AUDIO_H_
#define DAC_AUDIO_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
    
/**********DEFINED CONSTANTS**********/

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
uint8 isSongFinished(void);
uint8 playAudioTone(uint8 bSpeaker, enum ToneType songChoice, uint8 bAudioInput);
uint8 stopAudioTone(uint8 bSpeaker);
void updateDAC1(void);
void updateDAC2(void);
uint8 isAudioActive(void);
void deactivateAudio(void);

#endif
/* [] END OF FILE */
