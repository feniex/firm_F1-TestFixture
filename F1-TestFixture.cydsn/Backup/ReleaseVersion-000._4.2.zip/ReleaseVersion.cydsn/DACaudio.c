/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "SirenState.h"
#include "DACaudio.h"
#include "FileDecode.h"
    
/**********DEFINED CONSTANTS**********/
static const uint8 INITIAL_DAC_VALUE = 128;

static const uint8 DEFAULT_CHANNEL_COUNT = 1;
static const uint32 DEFAULT_SAMPLING_RATE = 8000; 

static const uint32 ECTO_CYCLE_START_INDEX = 12090;
static const uint32 ECTO_CYCLE_END_INDEX = 23940;
static const uint32 ECTO_RAMP_DOWN_INDEX = 83210;

/**********DATA STRUCTURES**********/
typedef struct
{
    uint8 channelCount;
    uint8 bytesPerSample;
    uint32 samplingRate;
    uint32 dataSize;
}DACdata;

/**********GLOBAL VARIABLES**********/
static enum ToneType currentSongNumber = NO_TONE;
static uint32 dataIndex = 0;

static uint8 bCurrentSpeaker = SPEAKER_1;
static uint8 bAudioInputFlag = false;

static uint8 bAudioActive = false;
static uint8 bSongFinishedFlag = false;

static DACdata Speaker1 = {0, 0, 0, 0};
static DACdata Speaker2 = {0, 0, 0, 0};

/**********FUNCTION PROTOTYPES**********/
static uint8 isMusicReady(enum ToneType songChoice);
static uint16 getSamplingReloadValue(uint32 frequency);

/**********DEFINED FUNCTIONS**********/
/*******************************************************************************
* Function Name: isSongFinished
********************************************************************************
*
* Summary:
*  Returns the status for song completion.
*
* Parameters: 
*   None
*
* Return:
*   TRUE if the song completed, FALSE if not completed
*
*******************************************************************************/
uint8 isSongFinished(void)
{
    return bSongFinishedFlag;
}

/*******************************************************************************
* Function Name: playAudioTone
********************************************************************************
*
* Summary:
*  Starts playing file song by updating the DAC at the sampling rate
*
* Parameters: 
*   bSpeaker: The speaker to update
*   songChoice: The value that represents the song selection
*   bAudioInput: The input status for the song selection
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
uint8 playAudioTone(uint8 bSpeaker, enum ToneType songChoice, uint8 bAudioInput)
{   
    uint16 DACreloadValue = 0;
    
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    if((bAudioInput != true) && (bAudioInput != false))
        return false;
    
    if((songChoice < ECTOSIREN) || (songChoice > REMAIN_WINDOW_DOWN))
    {
        if(songChoice == NO_TONE)
            currentSongNumber = songChoice;

        return false;
    }
    
    if((currentSongNumber != songChoice) || ((currentSongNumber == songChoice) && (!bAudioActive)))
    {
        if(!isMusicReady(songChoice))
            return false;

        currentSongNumber = songChoice;
        dataIndex = 0;
        bSongFinishedFlag = false;
    }
    
    bCurrentSpeaker = bSpeaker;
    bAudioInputFlag = bAudioInput;
    
    if((Speaker1.channelCount == DEFAULT_CHANNEL_COUNT) && 
        (Speaker1.samplingRate == DEFAULT_SAMPLING_RATE))
    {
        AMux1_FastSelect(DAC_MODE);
        AMux2_FastSelect(DAC_MODE);
        
        DACreloadValue = getSamplingReloadValue(Speaker1.samplingRate);        
        DACtimer1_Start();        
        DACtimer1_WritePeriod(DACreloadValue);
        
        PGA_1_Start();   
        VDAC8_1_Start();
        VDAC8_1_SetValue(INITIAL_DAC_VALUE);
        
        PGA_2_Start();   
        VDAC8_2_Start();
        VDAC8_2_SetValue(INITIAL_DAC_VALUE);
    }
        
    return true;
}

/*******************************************************************************
* Function Name: stopAudioTone
********************************************************************************
*
* Summary:
*  Stops the file song by disabling the DAC timer
*
* Parameters: 
*   bSpeaker: The speaker to update
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
uint8 stopAudioTone(uint8 bSpeaker){
    
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    DACtimer1_Stop();
    VDAC8_1_SetValue(INITIAL_DAC_VALUE);
    VDAC8_1_Stop();
    PGA_1_Stop();
    
    VDAC8_2_SetValue(INITIAL_DAC_VALUE);
    VDAC8_2_Stop();
    PGA_2_Stop(); 
    
    return true;
}

/*******************************************************************************
* Function Name: updateDAC1
********************************************************************************
*
* Summary:
*  Updates the value for DAC1 based on the file data
*
* Parameters: 
*   None
*
* Return:
*   None
*
*******************************************************************************/
void updateDAC1(void)
{
    uint8 DACvalue = 0;
    
    DACtimer1_ReadStatusRegister(); 
    CyWdtClear();
    
    DACvalue = getNextWaveData(dataIndex); //Obtains next byte to send to DAC
    
    VDAC8_1_SetValue(DACvalue); //Update both DACs at the same time for sync
    VDAC8_2_SetValue(DACvalue);
            
    dataIndex = (dataIndex + 1) % Speaker1.dataSize; //Increment index for song data, resets after getting to end of list
    
    switch(currentSongNumber)
    {
        case ECTOSIREN:
            if(!bAudioActive)   //Variable stays high until tone is complete
                bAudioActive = true;
            
            if(dataIndex == 0)
            {   //Reached end of ramp down
                bAudioActive = false;
                //ModeStatusISR_SetPending();
                disableAudioAndPWM();
                disableBothSpeakers();
            }
            else if((dataIndex >= ECTO_CYCLE_END_INDEX) && (dataIndex < ECTO_RAMP_DOWN_INDEX))
            {   //Reached end of ecto cycle
                if(bAudioInputFlag)
                    dataIndex = ECTO_CYCLE_START_INDEX;
                else
                    dataIndex = ECTO_RAMP_DOWN_INDEX;
            }
            break;
        //case GHOSTBUSTERS:
        case COPS_SONG:
            if(!bAudioActive)   //Variable stays high until tone is complete
                bAudioActive = true;
            
            if(dataIndex == 0)
            {   //Reached end of song
                bAudioActive = false;
                bSongFinishedFlag = true;
                PowerAmpOutput1_Write(false);   //Turn off song
                //PowerAmpOutput1_Write(false);
                stopAudioTone(SPEAKER_1);
            }
            break;
        case MOVE_OUT:
        case PULL_OVER:
        case STEP_OUT:
        case STEP_OUT_HANDS_UP:
        case REMAIN_IN_VEHICLE:
        case REMAIN_WINDOW_DOWN:
            if(!bAudioActive)
                bAudioActive = true;
            
            if((dataIndex == 0) && (!bAudioInputFlag))
            {   //Reached end of command
                bAudioActive = false;
                //ModeStatusISR_SetPending();
                disableAudioAndPWM();
                disableBothSpeakers();
            }
            break;
        default:
            break;
    }
}

/*******************************************************************************
* Function Name: updateDAC2
********************************************************************************
*
* Summary:
*  Updates the value for DAC2 based on the file data
*
* Parameters: 
*   None
*
* Return:
*   None
*
*******************************************************************************/
void updateDAC2(void)
{
    //static uint32 dataIndex = 0;
    uint8 DACvalue = 0;
    
    DACtimer2_ReadStatusRegister();   
    CyWdtClear();
    
    DACvalue = getNextWaveData(dataIndex); 
    
    if(Speaker2.bytesPerSample == 1)
    {   //8-bit data
        if(Speaker2.channelCount == 1)
            VDAC8_2_SetValue(DACvalue);
        else
        {   //2 channels
            if((dataIndex % 2) == 0)
                VDAC8_1_SetValue(DACvalue);
            else
                VDAC8_2_SetValue(DACvalue);
        }
        
        dataIndex = (dataIndex + 1) % Speaker2.dataSize;
    }
    else
    {   //16-bit data
        if(Speaker2.channelCount == 1)
            VDAC8_2_SetValue(DACvalue);
        else
        {   //2 channels
            if((dataIndex % 4) == 0)
                VDAC8_1_SetValue(DACvalue);
            else
                VDAC8_2_SetValue(DACvalue);
        }
        
        dataIndex = (dataIndex + 2) % Speaker2.dataSize;
    }
}

/*******************************************************************************
* Function Name: isAudioActive
********************************************************************************
*
* Summary:
*  Returns the status of an audio tone
*
* Parameters: 
*   None
*
* Return:
*   TRUE if active, FALSE if inactive
*
*******************************************************************************/
uint8 isAudioActive(void)
{
    return bAudioActive;
}

/*******************************************************************************
* Function Name: deactivateAudio
********************************************************************************
*
* Summary:
*  Updates the boolean to deactivate an audio tone
*
* Parameters: 
*   None
*
* Return:
*   None
*
*******************************************************************************/
void deactivateAudio(void)
{
    bAudioActive = false;
}

/*******************************************************************************
* Function Name: isMusicReady
********************************************************************************
*
* Summary:
*  Verifies that music file is valid and obtains data to process file
*
* Parameters: 
*   None
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 isMusicReady(enum ToneType songChoice)
{
    if((songChoice < ECTOSIREN) || (songChoice > REMAIN_WINDOW_DOWN))
        return false;
    
    if(!processHeaderData(songChoice))
		return false;
	
	Speaker1.channelCount = getChannelCount();
	Speaker1.bytesPerSample = getBytesPerSample();
	Speaker1.dataSize = getDataSize();
	Speaker1.samplingRate = getSamplingRate();
		
	return true;
}

/*******************************************************************************
* Function Name: getSamplingReloadValue
********************************************************************************
*
* Summary:
*  Calculates the corresponding reload value for the sampling rate
*
* Parameters: 
*   samplingRate: The 32-bit sampling rate in Hertz
*
* Return:
*   The corresponding reload value
*
*******************************************************************************/
static uint16 getSamplingReloadValue(uint32 samplingRate)
{
    static const uint32 TIMER_FREQUENCY = 48000000;
    return (uint16)(TIMER_FREQUENCY / samplingRate);
}

/* [] END OF FILE */