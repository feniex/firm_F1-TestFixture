/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include <string.h>

#define SONG_COUNT              9//10

#define BITS_PER_BYTE           8
#define MAX_READ_SIZE           4

#define ID_SIZE                 4
#define FORMAT_SIZE             4
#define SUBCHUNK_SIZE_FOR_PCM   16
#define AUDIO_FORMAT_VALUE      1   //PCM, values other than 1 indicate compression
#define MAX_CHANNEL_COUNT       2
#define EXPECTED_SAMPLING_RATE  8000

#define HEADER_SIZE             44    
#define NO_COMPARE_VALUE        0

/**********DEFINED CONSTANTS**********/
enum HeaderDataStartIndex
{
    WAVE_CHUNK_ID = 0,
    WAVE_CHUNK_SIZE = 4,
    WAVE_CHUNK_FORMAT = 8,
    
    FIRST_SUBCHUNK_ID = 12,
    FIRST_SUBCHUNK_SIZE = 16,
    FIRST_SUBCHUNK_AUDIO_FORMAT = 20,
    FIRST_SUBCHUNK_CHANNEL_COUNT = 22,
    FIRST_SUBCHUNK_SAMPLE_RATE = 24,
    FIRST_SUBCHUNK_BYTE_RATE = 28,
    FIRST_SUBCHUNK_BLOCK_ALIGN = 32,
    FIRST_SUBCHUNK_BITS_PER_SAMPLE = 34,
    
    SECOND_SUBCHUNK_ID = 36,
    SECOND_SUBCHUNK_SIZE = 40,
    SECOND_SUBCHUNK_DATA = 44
};

static const uint8 READ_COMMAND = 0x03;
static const uint32 BYTE_SHIFT_FACTOR = 256;

static const uint8 LOWEST_DAC_VALUE = 0x00;
static const uint8 CENTER_DAC_VALUE = 0x80;
static const uint8 HIGHEST_DAC_VALUE = 0xFF;

/**********DATA STRUCTURES**********/
static uint8 headerArray[HEADER_SIZE];

static const uint32 SONG_START_ADDRESS[SONG_COUNT] = 
{   0x00,       //ECTOSIREN
    //0x18420,    //GHOSTBUSTERS
    0x1DFBD0,   //COPS_SONG
    0x38B340,   //MOVE_OUT
    0x38EA70,   //PULL_OVER
    0x3911D0,   //STEP_OUT
    0x395430,   //STEP_OUT_HANDS_UP
    0x39BAB0,   //REMAIN_IN_VEHICLE
    0x39FAC0,   //REMAIN_WINDOW_DOWN
    0x3A6180    //MECHANICAL_DAC
};

static struct
{
    uint8 ID[ID_SIZE];
    uint32 size;
    uint8 format[FORMAT_SIZE];
}WaveChunk;

static struct
{
    uint8 ID[ID_SIZE];
    uint32 size;
    uint32 audioFormat;     // 1 for PCM
    uint32 channelCount;    // 1 or 2
    uint32 sampleRate;      // samples per second
    uint32 byteRate;        // bytes per second (for both channels)
    uint32 blockAlign;      // bytes per sample (for both channels)
    uint32 bitsPerSample;   // expecting either 8 or 16
}FirstSubChunk;

static struct
{
    uint8 ID[ID_SIZE];
    uint32 size;
}SecondSubChunk;

/**********GLOBAL VARIABLES**********/
static enum ToneType currentSong = NO_TONE;

/**********FUNCTION PROTOTYPES**********/
static uint8 adjustDACvalue(uint8 oldDACvalue);
static uint8 convertToUnsignedByte(int16 signedValue);
static uint8 processBigEndianData(uint8* dataArray, uint8* headerSubArray, char* compareString, uint8 arraySize);
static uint8 processLittleEndianData(uint32* dataParameter, uint8* headerSubArray, uint16 compareValue, uint8 byteCount);
static uint32 convertToBigEndian(uint32 littleEndianValue, uint8 byteCount);

/**********DEFINED FUNCTIONS**********/

/*******************************************************************************
* Function Name: getChannelCount
********************************************************************************
*
* Summary:
*  Returns the channel count for the current file
*
* Parameters: 
*   None
*
* Return:
*   The channel count as 1 or 2
*
*******************************************************************************/
uint8 getChannelCount(void)
{
	return (uint8)(FirstSubChunk.channelCount);
}

/*******************************************************************************
* Function Name: getBytesPerSample
********************************************************************************
*
* Summary:
*  Returns the number of bytes in each sample
*
* Parameters: 
*   None
*
* Return:
*   The number of bytes per sample as 1 or 2
*
*******************************************************************************/
uint8 getBytesPerSample(void)
{
	return (uint8)(FirstSubChunk.blockAlign);
}

/*******************************************************************************
* Function Name: getSamplingRate
********************************************************************************
*
* Summary:
*  Returns the sampling rate for the current file
*
* Parameters: 
*   None
*
* Return:
*   The sampling rate in Hertz
*
*******************************************************************************/
uint32 getSamplingRate(void)
{
	return FirstSubChunk.sampleRate;
}

/*******************************************************************************
* Function Name: getDataSize
********************************************************************************
*
* Summary:
*  Returns the number of data sample bytes for the current file
*
* Parameters: 
*   None
*
* Return:
*   The number of data sample bytes
*
*******************************************************************************/
uint32 getDataSize(void)
{
	return SecondSubChunk.size;
}

/*******************************************************************************
* Function Name: getNextWaveData
********************************************************************************
*
* Summary:
*  Gets the next 8-bit value to send out to the DAC, called in the DAC1_ISR or DAC2_ISR
*
* Parameters: 
*   addressIndex: The index to retrieve the next data point
*
* Return:
*   The DAC value ranging 0 - 255
*
*******************************************************************************/
uint8 getNextWaveData(uint32 addressIndex)
{ 
    static uint8 bFirstTime = true;
    uint8 addressMSB = 0;
    uint8 addressCSB = 0;
    uint8 addressLSB = 0;
    uint8 DACvalue = CENTER_DAC_VALUE;
    
    addressIndex += SONG_START_ADDRESS[currentSong-ECTOSIREN] + (uint32)(SECOND_SUBCHUNK_DATA);
    
    addressMSB = (uint8)((addressIndex & 0xFF0000) / (BYTE_SHIFT_FACTOR * BYTE_SHIFT_FACTOR));
    addressCSB = (uint8)((addressIndex & 0xFF00) / BYTE_SHIFT_FACTOR);
    addressLSB = (uint8)(addressIndex & 0x00FF);    //Splits the 24-bit address up into 3 separate bytes for SPI
    
    if(SPIM_ReadTxStatus() & SPIM_STS_SPI_IDLE)
    {   //Chip Select is high and the SPI transmission is done
        if(bFirstTime)
            bFirstTime = false; //Don't read on first iteration, just send command and address
        else
            DACvalue = SPIM_ReadRxData();   //Retrieve next DAC value from the SPI buffer
            
        SPIM_WriteTxData(READ_COMMAND); //Send command (8 bits)
        SPIM_WriteTxData(addressMSB);   //Send address (24 bits)
        SPIM_WriteTxData(addressCSB);
        SPIM_WriteTxData(addressLSB);        
        SPIM_WriteTxData(0x00);         //Send dummy byte (8 bits) to make total of 40 SPI clock cycles
    }

    return DACvalue;
}

/*******************************************************************************
* Function Name: processHeaderData
********************************************************************************
*
* Summary:
*  Verifies valid file by inspecting the header content
*
* Parameters: 
*   None
*
* Return:
*   TRUE for valid header, FALSE otherwise
*
*******************************************************************************/
uint8 processHeaderData(enum ToneType songChoice)
{  
    uint32 address = 0;
    uint8 addressMSB = 0;
    uint8 addressCSB = 0;
    uint8 addressLSB = 0;
    uint8 index = 0;
    
    if((songChoice < ECTOSIREN) || (songChoice > REMAIN_WINDOW_DOWN))
        return false;
    
    currentSong = songChoice;
    address = SONG_START_ADDRESS[currentSong-ECTOSIREN];
    
    addressMSB = (uint8)((address & 0xFF0000) / (BYTE_SHIFT_FACTOR * BYTE_SHIFT_FACTOR));
    addressCSB = (uint8)((address & 0xFF00) / BYTE_SHIFT_FACTOR);
    addressLSB = (uint8)(address & 0x00FF);
    
    for(index = 0; index < HEADER_SIZE; index++)
    {
        SPIM_WriteTxData(READ_COMMAND);         //Send command (8 bits)
        SPIM_WriteTxData(addressMSB);
        SPIM_WriteTxData(addressCSB);           //Send address (24 bits)
        SPIM_WriteTxData(addressLSB + index);
        
        SPIM_WriteTxData(0x00);                 //Send dummy byte (8 bits) to make total of 40 SPI clock cycles
        while(!(SPIM_ReadTxStatus() & SPIM_STS_SPI_IDLE)){} //Wait for Chip Select to go high
        headerArray[index] = SPIM_ReadRxData(); //Retrieve next header data from the SPI buffer
    }
    
    if(!processBigEndianData(WaveChunk.ID, &headerArray[WAVE_CHUNK_ID], "RIFF", ID_SIZE))
        return false;
		
	if(!processLittleEndianData(&WaveChunk.size, &headerArray[WAVE_CHUNK_SIZE], NO_COMPARE_VALUE, MAX_READ_SIZE))
		return false;

	if(!processBigEndianData(WaveChunk.format, &headerArray[WAVE_CHUNK_FORMAT], "WAVE", FORMAT_SIZE))
        return false;
		
	if(!processBigEndianData(FirstSubChunk.ID, &headerArray[FIRST_SUBCHUNK_ID], "fmt ", ID_SIZE))
        return false;
		
	if(!processLittleEndianData(&FirstSubChunk.size, &headerArray[FIRST_SUBCHUNK_SIZE], SUBCHUNK_SIZE_FOR_PCM, MAX_READ_SIZE))
		return false;
		
	if(!processLittleEndianData(&FirstSubChunk.audioFormat, &headerArray[FIRST_SUBCHUNK_AUDIO_FORMAT], AUDIO_FORMAT_VALUE, MAX_READ_SIZE/2))
		return false;
		
	if(!processLittleEndianData(&FirstSubChunk.channelCount, &headerArray[FIRST_SUBCHUNK_CHANNEL_COUNT], MAX_CHANNEL_COUNT, MAX_READ_SIZE/2))
		return false;
	
	if(!processLittleEndianData(&FirstSubChunk.sampleRate, &headerArray[FIRST_SUBCHUNK_SAMPLE_RATE], EXPECTED_SAMPLING_RATE, MAX_READ_SIZE))
		return false;
		
	if(!processLittleEndianData(&FirstSubChunk.byteRate, &headerArray[FIRST_SUBCHUNK_BYTE_RATE], NO_COMPARE_VALUE, MAX_READ_SIZE))
		return false;
		
	if(!processLittleEndianData(&FirstSubChunk.blockAlign, &headerArray[FIRST_SUBCHUNK_BLOCK_ALIGN], NO_COMPARE_VALUE, MAX_READ_SIZE/2))
		return false;
		
	if(!processLittleEndianData(&FirstSubChunk.bitsPerSample, &headerArray[FIRST_SUBCHUNK_BITS_PER_SAMPLE], NO_COMPARE_VALUE, MAX_READ_SIZE/2))
		return false;
	
	if(!processBigEndianData(SecondSubChunk.ID, &headerArray[SECOND_SUBCHUNK_ID], "data", ID_SIZE))
        return false;
		
	if(!processLittleEndianData(&SecondSubChunk.size, &headerArray[SECOND_SUBCHUNK_SIZE], NO_COMPARE_VALUE, MAX_READ_SIZE))
		return false;
    
    return true;
}

/*******************************************************************************
* Function Name: adjustDACvalue
********************************************************************************
*
* Summary:
*  Alters the current DAC value based on the offset and amplitude constants
*
* Parameters: 
*   oldDACvalue: The original value to send to the DAC
*
* Return:
*   The altered DAC value, should still be in range 0 - 255
*
*******************************************************************************/
static uint8 adjustDACvalue(uint8 oldDACvalue)
{
    static const uint8 OFFSET_VALUE = 0;
    static const uint8 AMPLITUDE_FACTOR = 1;
    uint8 newDACvalue = CENTER_DAC_VALUE;
    
    newDACvalue = oldDACvalue / AMPLITUDE_FACTOR + OFFSET_VALUE;
    
    if((oldDACvalue > LOWEST_DAC_VALUE) && (newDACvalue == LOWEST_DAC_VALUE))
        return LOWEST_DAC_VALUE;   //Indicates truncation at 0
    
    if((oldDACvalue < HIGHEST_DAC_VALUE) && (newDACvalue == HIGHEST_DAC_VALUE))
        return HIGHEST_DAC_VALUE;   //Indicates truncation at 255
    
    return newDACvalue;
}

/*******************************************************************************
* Function Name: convertToUnsignedByte
********************************************************************************
*
* Summary:
*  Converts a signed 16-bit value to an unsigned 8-bit value
*
* Parameters: 
*   signedValue: The 16-bit signed value
*
* Return:
*   The unsigned 8-bit value in range 0 - 255
*
*******************************************************************************/
static uint8 convertToUnsignedByte(int16 signedValue)
{
    static const int16 SIGNED_MASK = 0x8000;
    int16 adjustedValue = 0;
    
    if((FirstSubChunk.blockAlign == 1) &&
        ((signedValue < 0x0080) || (signedValue > 0x007F)))
        return 0;   //8-bit values must be in range -128 to 127
    
    if(FirstSubChunk.blockAlign == 2)
    {   //Convert 16-bit to 8-bit with rounding
        if(signedValue & SIGNED_MASK)
            adjustedValue = ((2 * signedValue - BYTE_SHIFT_FACTOR) / 2) / BYTE_SHIFT_FACTOR;
        else
            adjustedValue = ((2 * signedValue + BYTE_SHIFT_FACTOR) / 2) / BYTE_SHIFT_FACTOR;
    }
    
    adjustedValue += CENTER_DAC_VALUE;    //Add offset to meet range 0 - 255
    
	return (uint8)(adjustedValue);
}

/*******************************************************************************
* Function Name: processBigEndianData
********************************************************************************
*
* Summary:
*  Retrieves next header data and verifies that the big endian (ASCII) header 
*   parameters are valid
*
* Parameters: 
*   dataArray: The pointer to the array that will store the ASCII content
*   headerSubArray: The pointer to a section of the header array for validation
*   compareString: Used with the string compare function to check that the
*                   ASCII values are correct
*   arraySize: The number of elements to check in the arrays
*
* Return:
*   TRUE for valid content, FALSE otherwise
*
*******************************************************************************/
static uint8 processBigEndianData(uint8* dataArray, uint8* headerSubArray, char* compareString, uint8 arraySize)
{
    uint8 arrayCopy[MAX_READ_SIZE+1];
    uint8 index = 0;
    
    if((dataArray == NULL) || (headerSubArray == NULL) 
        || (compareString == NULL) || (arraySize > MAX_READ_SIZE)) 
        return false;   //Validate input parameters
    
    memset(arrayCopy, 0, MAX_READ_SIZE+1);  //Clear array
    
    for(index = 0; index < arraySize; index++)
        arrayCopy[index] = headerSubArray[index];   //Make copy of ASCII content + null character to compare strings
    
    if(strcmp((char*)(arrayCopy), compareString))   //0 for match, 1 for no match
		return false;
    
    for(index = 0; index < arraySize; index++)      //Matched, store ASCII content
        dataArray[index] = headerSubArray[index];
		
	return true;
}

/*******************************************************************************
* Function Name: processLittleEndianData
********************************************************************************
*
* Summary:
*  Retrieves next header data and verifies that the little endian header 
*   parameters are valid
*
* Parameters: 
*   dataParameter: The pointer to variable that will hold the next header data
*   headerSubArray: The pointer to a section of the header array for validation
*   compareValue: Used to verify that the tested value is in range
*   byteCount: Number of bytes to validate
*
* Return:
*   TRUE for valid content, FALSE otherwise
*
*******************************************************************************/
static uint8 processLittleEndianData(uint32* dataParameter, uint8* headerSubArray, uint16 compareValue, uint8 byteCount)
{
    uint8 index = 0;
	uint32 littleEndianValue = 0;
	uint32 bigEndianValue = 0;
	
	if((dataParameter == NULL) || (headerSubArray == NULL) || (byteCount > MAX_READ_SIZE))
		return false;   //Validate input parameters
	
	for(index = 0; index < byteCount; index++)
	{   //Convert bytes into one little endian value
		littleEndianValue *= BYTE_SHIFT_FACTOR;        
        littleEndianValue += headerSubArray[index];
	}
	
	bigEndianValue = convertToBigEndian(littleEndianValue, byteCount);
	if((compareValue != NO_COMPARE_VALUE) && (bigEndianValue > compareValue))
        return false;   //Check if the data meets the limitations
		
    *dataParameter = bigEndianValue;    //Passed check, store the value

	return true;
}

/*******************************************************************************
* Function Name: convertToBigEndian
********************************************************************************
*
* Summary:
*  Converts a little endian value to a big endian value
*
* Parameters: 
*   littleEndianValue: The little endian value
*   byteCount: The number of bytes to rearrange
*
* Return:
*   The big endian equivalent
*
*******************************************************************************/
static uint32 convertToBigEndian(uint32 littleEndianValue, uint8 byteCount)
{
    uint8 index = 0;
    uint32 bigEndianValue = 0;
    
    for(index = 0; index < byteCount; index++)
    {
        bigEndianValue *= BYTE_SHIFT_FACTOR;
        bigEndianValue += (littleEndianValue & 0xFF);
        littleEndianValue /= BYTE_SHIFT_FACTOR;        
    }
    
    return bigEndianValue;
}

/* [] END OF FILE */