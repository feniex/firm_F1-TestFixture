/* ========================================
 *
 * Copyright FENIEX INDUSTRIES, 2016
 * 200W SIREN
 *
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********CHANGE LOG**********/

#ifndef COMM_MANAGER_H_
#define COMM_MANAGER_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include <project.h>
    
/**********DEFINED CONSTANTS**********/

    
/**********DATA STRUCTURES**********/

    
/**********GLOBAL VARIABLES**********/

    
/**********GLOBAL FUNCTION PROTOTYPES**********/
void processByteReceivedHandler_UART_Audio(void);
void processByteReceivedHandler(void);
void processLED_TimerRoutine(void);
void processCommTimeoutRoutine(void);
void sendVersionPacket(void);    

#endif


/* [] END OF FILE */
