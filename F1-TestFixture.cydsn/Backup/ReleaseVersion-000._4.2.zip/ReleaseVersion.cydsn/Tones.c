/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "SirenState.h"
#include "Tones.h"

#define DECREASING	0
#define INCREASING	1

#define LOW_PITCH	0
#define HIGH_PITCH	1

#define TONE_STRUCT_SIZE    12
#define NOTES_TABLE_SIZE    25
#define TEST_TONE_INDEX     11

/**********DEFINED CONSTANTS**********/
static const uint16 HORN_FIRST_FREQUENCY = 1274;

enum ToneEffect
{
    NO_EFFECT,
    SYNC_TONES,
    DELAY_TONES
};

/**********DATA STRUCTURES**********/
typedef struct
{
    uint16 lowestFrequency;
    uint16 highestFrequency;
    uint16 delayUs;
    uint8 bWailEnable;
    uint8 bHornEnable;
}ToneStruct;

static ToneStruct toneList[TONE_STRUCT_SIZE] = 
{
    {0, 0, 880, false, false},          //0 NO TONE
    {725, 1500, 3500, true, false},     //1 WAIL
    {725, 1600, 220, false, false},     //2 SLOW YELP
    {725, 1600, 110, false, false},     //3 FAST YELP
    {650, 1725, 40, false, false},      //4 PHASER
    {600, 1200, 5000, false, false},    //5 HORN (this list order should match the enum list order)
    {770, 1370, 24000, true, true},     //6 MECHANICAL
    {725, 1500, 3500, true, false},     //7 MANUAL WAIL   
    {550, 750, 4000, false, false},     //8 HIGH/LOW    
    {500, 1075, 100, false, false},     //9 PCALL SLOW
    {500, 1075, 60, false, false},      //10 PCALL FAST
    {440, 1760, 4000, false, false}     //11 TEST TONE
};

typedef struct
{
    enum ToneType currentToneNumber;
    uint16 PWMperiodCount;
    uint16 PWMcountDifference;
    uint16 mechanicalRampUpCount;
    uint16 PCallHoldNoteCount;
    uint32 comboCount;
    uint8 bFrequencyChange;  
    uint8 bComboSwitch;
    uint8 bTonePlaying;
    uint8 bManualWailActiveFlag;
    uint8 bManualWailInputFlag;
    uint8 bHornPWMenable;   
    uint8 noteListIndex;
}CurrentToneData;

static const uint16 NOTES_FREQUENCY_LIST[NOTES_TABLE_SIZE] = {440, 466, 494, 524, 554, 588, 622, 660, 698, 740, 784, 830,
    880, 932, 988, 1046, 1108, 1174, 1244, 1318, 1396, 1480, 1568, 1660, 1760};

/**********GLOBAL VARIABLES**********/
static CurrentToneData speakerDataList[SPEAKER_COUNT] =
    {{NO_TONE, 1000, 0, 0, 0, 0, INCREASING, false, false, false, false, false, 0},
    {NO_TONE, 1000, 0, 0, 0, 0, INCREASING, false, false, false, false, false, 0}};
    
static enum ToneEffect toneEffectStatus = NO_EFFECT;
static uint8 bEchoEnable = false;

/**********FUNCTION PROTOTYPES**********/
static uint8 setToneEffectStatus(enum ToneType firstTone, enum ToneType secondTone, uint8 bDualDelayInput);
static uint8 playHornTone(CurrentToneData* currentSpeaker);
static uint8 playGradualChangeTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone);
static uint8 playManualWailTone(uint8 bSpeaker, CurrentToneData* currentSpeaker);
static uint8 playHighLowTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone);
static uint8 playMechanicalTone(CurrentToneData* currentSpeaker);
static uint8 playPCallTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone);
static uint8 playComboTone(uint8 bSpeaker, ToneStruct* firstToneChoice, ToneStruct* secondToneChoice);
static uint8 playTestTone(CurrentToneData* currentSpeaker);
static uint16 getCaptureValue(uint16 frequency);

/**********DEFINED FUNCTIONS**********/

/*******************************************************************************
* Function Name: playCurrentTone
********************************************************************************
*
* Summary:
*  Starts playing the selected tone by setting the PWM timer period and enabling
*  the PWM timer
*
* Parameters:  
*   bSpeaker: The speaker number SPEAKER_1 or SPEAKER_2
*   newTone: The value that represents the tone to play
*   bManualWailInput: The current status for the manual wail input
*   bDualDelayInput: The currant status for the dual delay input
*
* Return:
*   TRUE for valid input, FALSE otherwise
*
*******************************************************************************/
uint8 playPWMTone(uint8 bSpeaker, enum ToneType newTone, uint8 bManualWailInput, uint8 bDualDelayInput)
{
    if(((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2)) ||
        ((newTone < NO_TONE) || (newTone > PHASER_YELP && newTone != TEST_TONE)) ||
        ((bManualWailInput != false) && (bManualWailInput != true)) ||
        ((bDualDelayInput != false) && (bDualDelayInput != true)))
        return false;
    
    speakerDataList[bSpeaker].currentToneNumber = newTone; //Update global variables
    speakerDataList[bSpeaker].bManualWailInputFlag = bManualWailInput;
    
    setToneEffectStatus(speakerDataList[SPEAKER_1].currentToneNumber,   //Updates global variable toneEffectStatus
        speakerDataList[SPEAKER_2].currentToneNumber, bDualDelayInput);
       
    if(speakerDataList[bSpeaker].currentToneNumber != NO_TONE)
    {
        if(!bSpeaker)
        {   //Start timer and PWM for SPEAKER 1
            PWMtimer1_Start();    //Need to start timer before updating the period
            
            if((speakerDataList[bSpeaker].currentToneNumber >= HORN_PHASER) && 
                (speakerDataList[bSpeaker].currentToneNumber <= PHASER_YELP))
            {   //Update timer period for a combo tone
                switch(speakerDataList[bSpeaker].currentToneNumber)
                {
                    case HORN_PHASER:
                        PWMtimer1_WritePeriod(toneList[HORN].delayUs);
                        break;
                    case HORN_YELP:
                        PWMtimer1_WritePeriod(toneList[HORN].delayUs);
                        break;
                    case PHASER_YELP:
                        PWMtimer1_WritePeriod(toneList[PHASER].delayUs);
                        break;
                    default:
                        break;
                }
                
                speakerDataList[bSpeaker].bComboSwitch = false;            
            }
            else if(speakerDataList[bSpeaker].currentToneNumber == TEST_TONE)
                PWMtimer1_WritePeriod(toneList[TEST_TONE_INDEX].delayUs);
            else    //Update timer period for every other siren tone
                PWMtimer1_WritePeriod(toneList[speakerDataList[bSpeaker].currentToneNumber].delayUs);
            
            AMux1_FastSelect(PWM_MODE);
            PWM_1_Start();
        }
        else
        {   //Start timer and PWM for SPEAKER 2
            if(toneEffectStatus != SYNC_TONES)
            {   //this timer is only used when the tones are NOT in sync
                if((toneEffectStatus != DELAY_TONES) || (bEchoEnable == true))
                {   //The timer for Speaker 2 will be called later to create delay
                    PWMtimer2_Start();   //Need to start timer before updating the period
                    
                    if((speakerDataList[bSpeaker].currentToneNumber >= HORN_PHASER) && 
                        (speakerDataList[bSpeaker].currentToneNumber <= PHASER_YELP))
                    {
                        switch(speakerDataList[bSpeaker].currentToneNumber)
                        {   //Update timer period for a combo tone
                            case HORN_PHASER:
                                PWMtimer2_WritePeriod(toneList[HORN].delayUs);
                                break;
                            case HORN_YELP:
                                PWMtimer2_WritePeriod(toneList[HORN].delayUs);
                                break;
                            case PHASER_YELP:
                                PWMtimer2_WritePeriod(toneList[PHASER].delayUs);
                                break;
                            default:
                                break;
                        }
                        
                        speakerDataList[bSpeaker].bComboSwitch = false;            
                    }
                    else if(speakerDataList[bSpeaker].currentToneNumber == TEST_TONE)
                        PWMtimer2_WritePeriod(toneList[TEST_TONE_INDEX].delayUs);
                    else    //Update timer period for every other siren tone
                        PWMtimer2_WritePeriod(toneList[speakerDataList[bSpeaker].currentToneNumber].delayUs);
                }
            }
            
            if((toneEffectStatus != DELAY_TONES) || (bEchoEnable == true))
            {   //The PWM for Speaker 2 will be called later to create delay, still needs to be enabled for sync
                AMux2_FastSelect(PWM_MODE);
                PWM_2_Start();
            }
            
            if(toneEffectStatus == DELAY_TONES)
                bEchoEnable = true;
        }
    }
    
    return true;
}

/*******************************************************************************
* Function Name: stopCurrentTone
********************************************************************************
*
* Summary:
*  Stops playing the selected tone by disabling the PWM timer, typically called
*  during an input change
*
* Parameters:  
*   bSpeaker: The speaker number SPEAKER_1 or SPEAKER_2
*
* Return:
*   TRUE for valid input, FALSE otherwise
*
*******************************************************************************/
uint8 stopPWMTone(uint8 bSpeaker)
{
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    if(bSpeaker)
    {
        PWM_2_WriteCompare(0);
        PWM_2_Stop();
        PWMtimer2_Stop();
    }
    else
    {
        PWM_1_WriteCompare(0);     //Keeps PWM signals low once tone stops
        PWM_1_Stop();
        PWMtimer1_Stop(); 
    }
    
    toneEffectStatus = NO_EFFECT;
    speakerDataList[bSpeaker].bFrequencyChange = INCREASING;
    speakerDataList[bSpeaker].bTonePlaying = false;
    speakerDataList[bSpeaker].bHornPWMenable = false;   
    speakerDataList[bSpeaker].noteListIndex = 0;
       
    return true;
}

/*******************************************************************************
* Function Name: processPWMtimerRoutine
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value periodically depending on the selected tone
*  and speaker, called in the PWMtimerISR
*
* Parameters:  
*   bSpeaker: The speaker number, SPEAKER_1 or SPEAKER_2
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
uint8 processPWMtimerRoutine(uint8 bSpeaker)
{   
    if(bSpeaker)
        PWMtimer2_ReadStatusRegister();  //Clears the sticky interrupt bit
    else
        PWMtimer1_ReadStatusRegister();
    
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    CyWdtClear();   //Reset watchdog timer periodically

    switch(speakerDataList[bSpeaker].currentToneNumber)
	{
        case WAIL:
        case SLOW_YELP:
        case FAST_YELP:
		case PHASER:
            playGradualChangeTone(&speakerDataList[bSpeaker], &toneList[speakerDataList[bSpeaker].currentToneNumber]);
            break;
        case HORN:
			playHornTone(&speakerDataList[bSpeaker]);
			break;
        case MECHANICAL:
			playMechanicalTone(&speakerDataList[bSpeaker]);
			break;
		case MANUAL_WAIL:
			playManualWailTone(bSpeaker, &speakerDataList[bSpeaker]);
			break;		
		case HIGH_LOW:
            playHighLowTone(&speakerDataList[bSpeaker],&toneList[speakerDataList[bSpeaker].currentToneNumber]);
            break;
        case PCALL_SLOW:
        case PCALL_FAST:             
            playPCallTone(&speakerDataList[bSpeaker], &toneList[speakerDataList[bSpeaker].currentToneNumber]);
			break;
        case HORN_PHASER:
            playComboTone(bSpeaker, &toneList[HORN], &toneList[PHASER]);
            break;
        case HORN_YELP:
            playComboTone(bSpeaker, &toneList[HORN], &toneList[FAST_YELP]);
            break;
        case PHASER_YELP:
            playComboTone(bSpeaker, &toneList[PHASER], &toneList[FAST_YELP]);
            break;
        case TEST_TONE:
            playTestTone(&speakerDataList[bSpeaker]);
            break;
        default:
            break;
	}
    
    return true;
}

/*******************************************************************************
* Function Name: processPWM1updateRoutine
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value and duty cycle value at the end of each PWM cycle,
*  called in the PWM_ISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processPWM1updateRoutine(void)
{
    static const uint8 HORN_FREQUENCY_COUNT_LIMIT = 1;
    static uint8 hornFrequencyCount = 0;
    uint16 captureValue = 0;
    
    static const uint8 HORN_WIGGLE_WIDTH = 20;
    static uint8 bFrequencyChange = INCREASING;
    static uint8 hornWiggleCount = 0;
    
    PWM_1_ReadStatusRegister();    //Clears the sticky interrupt bit
    
    if(speakerDataList[SPEAKER_1].bHornPWMenable)
    {
        switch(hornFrequencyCount)
        {   //Used to switch between 2 PWM patterns to create the horn effect
            case 0:
                captureValue = getCaptureValue(HORN_FIRST_FREQUENCY) + hornWiggleCount;
                
                if(bFrequencyChange == INCREASING)
                    hornWiggleCount += 2;   //Creates vibrato effect at this frequency
                else
                    hornWiggleCount -= 2;
                
                if(hornWiggleCount <= 0)
                    bFrequencyChange = INCREASING;
                else if(hornWiggleCount >= HORN_WIGGLE_WIDTH)
                    bFrequencyChange = DECREASING;
                break;
            case 1:
                captureValue = speakerDataList[SPEAKER_1].PWMperiodCount;
                break;
        }
        
        if(hornFrequencyCount < HORN_FREQUENCY_COUNT_LIMIT)
            hornFrequencyCount++;
        else
            hornFrequencyCount = 0;
    }
    else    //When there is no horn effect
        captureValue = speakerDataList[SPEAKER_1].PWMperiodCount;
        
    PWM_1_WritePeriod(captureValue);    //Load new value to the PWM peripheral
    PWM_1_WriteCompare(captureValue/2);
    
    if(toneEffectStatus == SYNC_TONES)
    {   //Update PWM 2 as well during sync, uses Speaker 1's capture value
        PWM_2_WritePeriod(captureValue);
        PWM_2_WriteCompare(captureValue/2);
    }
}

/*******************************************************************************
* Function Name: processPWM2updateRoutine
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value and duty cycle value at the end of each PWM cycle,
*  called in the PWM_ISR
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void processPWM2updateRoutine(void)
{
    static const uint8 HORN_FREQUENCY_COUNT_LIMIT = 1;
    static uint8 hornFrequencyCount = 0;
    uint16 captureValue = 0;
    
    static const uint8 HORN_WIGGLE_WIDTH = 20;
    static uint8 bFrequencyChange = INCREASING;
    static uint8 hornWiggleCount = 0;
    
    PWM_2_ReadStatusRegister();    //Clears the sticky interrupt bit
    
    if(toneEffectStatus != SYNC_TONES)
    {   //Only update PWM 2 in this routine when not in sync
        if(speakerDataList[SPEAKER_2].bHornPWMenable)
        {
            switch(hornFrequencyCount)
            {   //Used to switch between 2 PWM patterns to create the horn effect
                case 0:
                    captureValue = getCaptureValue(HORN_FIRST_FREQUENCY) + hornWiggleCount;
                    
                    if(bFrequencyChange == INCREASING)
                        hornWiggleCount += 2; //Creates vibrato effect at this frequency
                    else
                        hornWiggleCount -= 2;
                    
                    if(hornWiggleCount <= 0)
                        bFrequencyChange = INCREASING;
                    else if(hornWiggleCount >= HORN_WIGGLE_WIDTH)
                        bFrequencyChange = DECREASING;
                    
                    break;
                case 1:
                    captureValue = speakerDataList[SPEAKER_2].PWMperiodCount;
                    break;
            }
            
            if(hornFrequencyCount < HORN_FREQUENCY_COUNT_LIMIT)
                hornFrequencyCount++;
            else
                hornFrequencyCount = 0;
        }
        else //When there is no horn effect
            captureValue = speakerDataList[SPEAKER_2].PWMperiodCount;
            
        PWM_2_WritePeriod(captureValue);
        PWM_2_WriteCompare(captureValue/2);
    }
}

/*******************************************************************************
* Function Name: isManualWailActive
********************************************************************************
*
* Summary:
*  Returns the boolean that determines if manual wail is active
*
* Parameters:  
*   bSpeaker: The speaker number, SPEAKER_1 or SPEAKER_2
*
* Return:
*   The boolean that determines if manual wail is active
*
*******************************************************************************/
uint8 isManualWailActive(uint8 bSpeaker)
{
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    return speakerDataList[bSpeaker].bManualWailActiveFlag;
}

/*******************************************************************************
* Function Name: deactivateManualWail
********************************************************************************
*
* Summary:
*  Clears the manual wail active flag so it won't continue playing after the tone changes
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void deactivateManualWail(void)
{
    speakerDataList[SPEAKER_1].bManualWailActiveFlag = false;
    speakerDataList[SPEAKER_2].bManualWailActiveFlag = false;
}

/*******************************************************************************
* Function Name: setToneEffectStatus
********************************************************************************
*
* Summary:
*  Determines if the qualifying tones need to be in sync or have delay
*
* Parameters:  
*   firstTone: The tone for Speaker 1
*   secondTone: The tone for Speaker 2
*   bDualDelayInput: The boolean that indicates if dual delay is enabled
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 setToneEffectStatus(enum ToneType firstTone, enum ToneType secondTone, uint8 bDualDelayInput)
{
    if((firstTone < NO_TONE) || (firstTone > PHASER_YELP))
        return false;
    
    if((secondTone < NO_TONE) || (secondTone > PHASER_YELP))
        return false;
    
    if((bDualDelayInput != true) && (bDualDelayInput != false))
        return false;
    
    if((firstTone == NO_TONE) || (secondTone == NO_TONE) || (firstTone != secondTone))
        toneEffectStatus = NO_EFFECT;
    else
    {   //Tones are the same
        if(bDualDelayInput == true)
        {
            if((firstTone == HORN) || (firstTone == MANUAL_WAIL) || (firstTone == TEST_TONE) || (firstTone > PCALL_FAST))
                toneEffectStatus = SYNC_TONES;
            else
                toneEffectStatus = DELAY_TONES;
        }
        else
            toneEffectStatus = SYNC_TONES;
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playHornTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the horn tone
*
* Parameters:  
*   currentSpeaker: The pointer to the struct for the current speaker's data
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 playHornTone(CurrentToneData* currentSpeaker)
{
	if(currentSpeaker == NULL)
        return false;
	
	if(currentSpeaker-> bFrequencyChange == HIGH_PITCH)
		currentSpeaker->PWMperiodCount = getCaptureValue(toneList[HORN].highestFrequency);
	else
		currentSpeaker->PWMperiodCount = getCaptureValue(toneList[HORN].lowestFrequency);
	
	currentSpeaker-> bFrequencyChange = !currentSpeaker-> bFrequencyChange;
        
    return true;
}

/*******************************************************************************
* Function Name: playGradualChangeTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the wail, yelp, and phaser tones
*
* Parameters:  
*   currentSpeaker: The pointer to the struct for the current speaker's data
*   currentTone: The pointer to the struct for the specified tone
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 playGradualChangeTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone)
{
	if((currentSpeaker == NULL) || (currentTone == NULL))
        return false;
    
    uint16 highestPWMcount = getCaptureValue(currentTone->lowestFrequency);
    uint16 lowestPWMcount = getCaptureValue(currentTone->highestFrequency);
    
    if(!currentSpeaker->bTonePlaying)
    {
        currentSpeaker->PWMcountDifference = highestPWMcount - lowestPWMcount;
        currentSpeaker->bTonePlaying = true;
    }

	if((currentTone->bWailEnable == true) && (currentSpeaker->bFrequencyChange == INCREASING))
		currentSpeaker->PWMperiodCount = lowestPWMcount + (uint16)((uint32)(currentSpeaker->PWMcountDifference) *
                            (uint32)(currentSpeaker->PWMcountDifference) / (uint32)(highestPWMcount - lowestPWMcount));
	else
		currentSpeaker->PWMperiodCount = lowestPWMcount + currentSpeaker->PWMcountDifference;
	
	if(currentSpeaker->bFrequencyChange == INCREASING)
	{
		currentSpeaker->PWMcountDifference--;			
		if(currentSpeaker->PWMcountDifference <= 0)
		{
			currentSpeaker->PWMcountDifference = 0;	//Reached highest frequency			
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;
            
            if(bEchoEnable)
            {
                playPWMTone(SPEAKER_2, currentSpeaker->currentToneNumber, false, true);
                bEchoEnable = false;
            }
		}
	}
	else
	{
		currentSpeaker->PWMcountDifference++;
		if(currentSpeaker->PWMcountDifference >= (highestPWMcount - lowestPWMcount))
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;	//Reached lowest frequency
	}
	
	return true;
}

/*******************************************************************************
* Function Name: playManualWailTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the manual wail tone
*
* Parameters:  
*   bSpeaker: The speaker number, SPEAKER_1 or SPEAKER_2
*   currentSpeaker: The pointer to the struct for the current speaker's data
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 playManualWailTone(uint8 bSpeaker, CurrentToneData* currentSpeaker)
{
	if((bSpeaker != false) && (bSpeaker != true))
        return false;
    
    if(currentSpeaker == NULL)
        return false;
    
    uint16 highestPWMcount = getCaptureValue(toneList[MANUAL_WAIL].lowestFrequency);
    uint16 lowestPWMcount = getCaptureValue(toneList[MANUAL_WAIL].highestFrequency);
	
	if(!currentSpeaker->bManualWailActiveFlag)
	{
        currentSpeaker->PWMcountDifference = highestPWMcount - lowestPWMcount;
    	currentSpeaker->bManualWailActiveFlag = true;
	}	
		
	if(currentSpeaker->bManualWailActiveFlag)
	{
		if(currentSpeaker->bManualWailInputFlag)
		{
			currentSpeaker->PWMperiodCount = lowestPWMcount + (uint16)((uint32)(currentSpeaker->PWMcountDifference) *
                                (uint32)(currentSpeaker->PWMcountDifference) / (uint32)(highestPWMcount - lowestPWMcount));
            
            if(currentSpeaker->PWMcountDifference > 0)//Reached highest frequency and stays there
			    currentSpeaker->PWMcountDifference--;
		}
		else
		{
			currentSpeaker->PWMperiodCount = lowestPWMcount + currentSpeaker->PWMcountDifference;
			currentSpeaker->PWMcountDifference++;
			
			if(currentSpeaker->PWMcountDifference >= (highestPWMcount - lowestPWMcount))
				currentSpeaker->bManualWailActiveFlag = false; //Reached lowest frequency and finishes tone
		}
	}
    
    if(!currentSpeaker->bManualWailActiveFlag)
    {
        deactivateManualWail(); //Disable manual wail for both speakers after first ramp down
        //ModeStatusISR_SetPending();
        disableAudioAndPWM();
        disableBothSpeakers();
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playHighLowTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the high low tone
*
* Parameters:  
*   currentSpeaker: The pointer to the struct for the current speaker's data
*   currentTone: The pointer to the struct for the specified tone
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 playHighLowTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone)
{
    static const uint16 HIGH_LOW_COUNT_LIMIT = 250;
    
    if((currentSpeaker == NULL) || (currentTone == NULL))
        return false;
    
    if(!currentSpeaker->bTonePlaying)
    {
        currentSpeaker->PWMcountDifference = 0;
        currentSpeaker->bTonePlaying = true;
    }
    
    if(!currentSpeaker->bHornPWMenable && currentTone->bHornEnable)
        currentSpeaker->bHornPWMenable = true;
		
	if(currentSpeaker->PWMcountDifference < HIGH_LOW_COUNT_LIMIT)
	{
		if(currentSpeaker->bFrequencyChange == HIGH_PITCH)
			currentSpeaker->PWMperiodCount = getCaptureValue(currentTone->highestFrequency);
		else
			currentSpeaker->PWMperiodCount = getCaptureValue(currentTone->lowestFrequency);
            
        currentSpeaker->PWMcountDifference++;
	}
    else
    {
        if(bEchoEnable)
        {
            playPWMTone(SPEAKER_2, currentSpeaker->currentToneNumber, false, true);
            bEchoEnable = false;
        }
        
        currentSpeaker->PWMcountDifference = 0;
        currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playMechanicalTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the mechanical tone
*
* Parameters:  
*   currentSpeaker: The pointer to the struct for the current speaker's data
*
* Return:
*   TRUE for valid inputs, FALSE otherwise
*
*******************************************************************************/
static uint8 playMechanicalTone(CurrentToneData* currentSpeaker)
{
    static const uint16 RAMP_UP_INITIAL_DIFFERENCE = 15;
    static const uint16 RAMP_UP_COUNT_LIMIT = 25;
    uint16 currentDifference = 1;   
    
    if(currentSpeaker == NULL)
        return false;
    
    uint16 highestPWMcount = getCaptureValue(toneList[MECHANICAL].lowestFrequency);
    uint16 lowestPWMcount = getCaptureValue(toneList[MECHANICAL].highestFrequency);
    
    if(!currentSpeaker->bTonePlaying)
    {
        currentSpeaker->PWMcountDifference = highestPWMcount - lowestPWMcount;
        currentSpeaker->bTonePlaying = true;
        currentSpeaker->bHornPWMenable = true;
        currentSpeaker->mechanicalRampUpCount = 0;
    }

	if(currentSpeaker->bFrequencyChange == INCREASING)
    {
		currentSpeaker->PWMperiodCount = lowestPWMcount + (uint16)((uint32)(currentSpeaker->PWMcountDifference) *
                            (uint32)(currentSpeaker->PWMcountDifference) / (uint32)(highestPWMcount - lowestPWMcount));
        
        if(currentSpeaker->mechanicalRampUpCount < RAMP_UP_COUNT_LIMIT)
            currentDifference = RAMP_UP_INITIAL_DIFFERENCE;
        else
            currentDifference = 1;
        
        currentSpeaker->mechanicalRampUpCount++;
        
        if(currentSpeaker->PWMcountDifference > 0 && currentSpeaker->PWMcountDifference < currentDifference)
			currentSpeaker->PWMcountDifference = currentDifference;
		else
			currentSpeaker->PWMcountDifference -= currentDifference;
        
		if(currentSpeaker->PWMcountDifference <= 0)
		{
			currentSpeaker->PWMcountDifference = 0;	//Reached highest frequency			
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;
            
            if(bEchoEnable)
            {
                playPWMTone(SPEAKER_2, currentSpeaker->currentToneNumber, false, true);
                bEchoEnable = false;
            }
		}
    }
	else
    {
		currentSpeaker->PWMperiodCount = lowestPWMcount + currentSpeaker->PWMcountDifference;        
        currentSpeaker->PWMcountDifference++;
        currentSpeaker->mechanicalRampUpCount = 0;
        
		if(currentSpeaker->PWMcountDifference >= (highestPWMcount - lowestPWMcount))
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;	//Reached lowest frequency
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playPCallTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the PCall Fast and Slow tones
*
* Parameters:  
*   currentSpeaker: The pointer to the struct for the current speaker's data
*   currentTone: The pointer to the PCall struct
*
* Return:
*   TRUE for valid input, FALSE otherwise
*
*******************************************************************************/
static uint8 playPCallTone(CurrentToneData* currentSpeaker, ToneStruct* currentTone)
{
    static const uint16 HOLD_NOTE_FACTOR = 35;
	
	if((currentSpeaker == NULL) || (currentTone == NULL))
		return false;
    
    uint16 highestPWMcount = getCaptureValue(currentTone->lowestFrequency);
    uint16 lowestPWMcount = getCaptureValue(currentTone->highestFrequency);
    
    if(!currentSpeaker->bTonePlaying)
    {
        currentSpeaker->PWMcountDifference = highestPWMcount - lowestPWMcount;
        currentSpeaker->bTonePlaying = true;
    }
    
    currentSpeaker->PWMperiodCount = lowestPWMcount + (uint16)((uint32)(currentSpeaker->PWMcountDifference) * 
                                    (uint32)(currentSpeaker->PWMcountDifference) / (uint32)(highestPWMcount - lowestPWMcount));
    
    if(currentSpeaker->bFrequencyChange == INCREASING)
    {
        currentSpeaker->PWMcountDifference--;
			
		if(currentSpeaker->PWMcountDifference <= 0)
		{	
			currentSpeaker->PWMcountDifference = 0;	//Reached highest frequency
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;
		}
    }
    else
    {
        if((currentSpeaker->PCallHoldNoteCount < (currentTone->delayUs * HOLD_NOTE_FACTOR)) && 
            (currentSpeaker->PWMcountDifference == 0))
        {
            if((currentSpeaker->PCallHoldNoteCount == ((currentTone->delayUs * HOLD_NOTE_FACTOR) / 2)) && 
                (bEchoEnable))
            {
                playPWMTone(SPEAKER_2, currentSpeaker->currentToneNumber, false, true);
                bEchoEnable = false;
            }
            
            currentSpeaker->PCallHoldNoteCount++;
        }
        else
            currentSpeaker->PWMcountDifference++;
		
		if(currentSpeaker->PWMcountDifference >= (highestPWMcount - lowestPWMcount))	
        {
            currentSpeaker->PCallHoldNoteCount = 0;
			currentSpeaker->bFrequencyChange = !currentSpeaker->bFrequencyChange;	//Reached lowest frequency	
        }
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playComboTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the Combo Tones
*
* Parameters:  
*   bSpeaker: The speaker number, SPEAKER_1 or SPEAKER_2
*   firstToneChoice - The pointer to the struct of the first tone
*   secondToneChoice - The pointer to the struct of the second tone
*
* Return:
*   TRUE for valid input, FALSE otherwise
*
*******************************************************************************/
static uint8 playComboTone(uint8 bSpeaker, ToneStruct* firstToneChoice, ToneStruct* secondToneChoice)
{
    static const uint32 COMBO_COUNT_LIMIT = 0x3FFFF;
    uint32 delayFactor1 = 0;
    uint32 delayFactor2 = 0;
    
    if((bSpeaker != SPEAKER_1) && (bSpeaker != SPEAKER_2))
        return false;
    
    if((firstToneChoice == NULL) || (secondToneChoice == NULL))
		return false;
    
    delayFactor1 = COMBO_COUNT_LIMIT / (uint32)(firstToneChoice->delayUs);
    delayFactor2 = COMBO_COUNT_LIMIT / (uint32)(secondToneChoice->delayUs);
    
    if(speakerDataList[bSpeaker].bComboSwitch)
    {
        if(speakerDataList[bSpeaker].comboCount < delayFactor2)
        {
            if(secondToneChoice == &toneList[HORN])
                playHornTone(&speakerDataList[bSpeaker]);
            else
                playGradualChangeTone(&speakerDataList[bSpeaker], secondToneChoice);
                
            speakerDataList[bSpeaker].comboCount++;
        }
        else
        {
            if(bSpeaker)
                PWMtimer2_WritePeriod(firstToneChoice->delayUs);
            else
                PWMtimer1_WritePeriod(firstToneChoice->delayUs);
            
            speakerDataList[bSpeaker].comboCount = 0;
            speakerDataList[bSpeaker].bComboSwitch = !speakerDataList[bSpeaker].bComboSwitch;
        }
    }
    else
    {
        if(speakerDataList[bSpeaker].comboCount < delayFactor1)
        {
            if(firstToneChoice == &toneList[HORN])
                playHornTone(&speakerDataList[bSpeaker]);
            else
                playGradualChangeTone(&speakerDataList[bSpeaker], firstToneChoice);
                
            speakerDataList[bSpeaker].comboCount++;
        }
        else
        {
            if(bSpeaker)
                PWMtimer2_WritePeriod(secondToneChoice->delayUs);
            else
                PWMtimer1_WritePeriod(secondToneChoice->delayUs);
            
            speakerDataList[bSpeaker].comboCount = 0;
            speakerDataList[bSpeaker].bComboSwitch = !speakerDataList[bSpeaker].bComboSwitch;
        }
    }
    
    return true;
}

/*******************************************************************************
* Function Name: playTestTone
********************************************************************************
*
* Summary:
*  Updates the PWM frequency value for the Test Tone
*
* Parameters:  
*   currentSpeaker: The pointer to the tone data struct for the current speaker
*
* Return:
*   TRUE for valid input, FALSE otherwise
*
*******************************************************************************/
static uint8 playTestTone(CurrentToneData* currentSpeaker)
{
    static const uint16 HIGH_LOW_COUNT_LIMIT = 250;
    
    if(currentSpeaker == NULL)
        return false;
    
    if(!currentSpeaker->bTonePlaying)
    {
        currentSpeaker->PWMcountDifference = 0;
        currentSpeaker->bTonePlaying = true;
    }
    
    if(currentSpeaker->PWMcountDifference < HIGH_LOW_COUNT_LIMIT)
	{
        currentSpeaker->PWMperiodCount = getCaptureValue(NOTES_FREQUENCY_LIST[currentSpeaker->noteListIndex]);
        currentSpeaker->PWMcountDifference++;
	}
    else
    {
        currentSpeaker->PWMcountDifference = 0;
        
        if(currentSpeaker->bFrequencyChange == INCREASING)
			currentSpeaker->noteListIndex++;
		else
			currentSpeaker->noteListIndex--;
        
        if(currentSpeaker->noteListIndex >= (NOTES_TABLE_SIZE - 1))
            currentSpeaker->bFrequencyChange = DECREASING;
        else if(currentSpeaker->noteListIndex <= 0)
            currentSpeaker->bFrequencyChange = INCREASING;
    }
    
    return true;
}

/*******************************************************************************
* Function Name: getCaptureValue
********************************************************************************
*
* Summary:
*  Converts a frequency value to the corresponding capture value for the
*  PWM timer that ticks at a rate of 1 MHz
*
* Parameters:  
*   frequency: In hertz
*
* Return:
*   The capture value
*
*******************************************************************************/
static uint16 getCaptureValue(uint16 frequency)
{
    static const uint32 PWM_CLOCK_FREQUENCY = 1000000;    
    return (uint16)(PWM_CLOCK_FREQUENCY / (uint32)(frequency));
}

/* [] END OF FILE */
