/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef SIRENSTATE_H_
#define SIRENSTATE_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
    
/**********DEFINED CONSTANTS**********/

/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
void initializeToneConfigurationList(void);
void initializeInputReadings(void);
void enableToneInputInterrupts(void);
void disableToneInputInterrupts(void);
void processRadioMicKeyRoutine(void);
void processParkKillRoutine(void);
void processTackSwitchRoutine(void);
void processHornRingRoutine(void);
void processDualDelayRoutine(void);
void processToneChangeRoutine(void);
uint8 setTonesWithCommunication(enum ToneType firstTone, enum ToneType secondTone, uint8 bDualDelay);
void disableAudioAndPWM(void);
void disableBothSpeakers(void);

#endif
/* [] END OF FILE */
