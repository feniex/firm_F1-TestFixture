/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef TONES_H_
#define TONES_H_
    
/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
    
/**********DEFINED CONSTANTS**********/
    
/**********DATA STRUCTURES**********/

/**********GLOBAL VARIABLES**********/

/**********FUNCTION PROTOTYPES**********/
uint8 playPWMTone(uint8 bSpeaker, enum ToneType newTone, uint8 bManualWailInput, uint8 bDualDelayInput);
uint8 stopPWMTone(uint8 bSpeaker);
uint8 processPWMtimerRoutine(uint8 bSpeaker);
void processPWM1updateRoutine(void);
void processPWM2updateRoutine(void);
uint8 isManualWailActive(uint8 bSpeaker);
void deactivateManualWail(void);

#endif
/* [] END OF FILE */
